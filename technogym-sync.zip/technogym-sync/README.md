# Sync WIC → Technogym

Estensione Chrome che, a vendita conclusa su **Wellness in Cloud**, registra la
stessa vendita come acquisto a **0 €** sull'anagrafica corrispondente in
**MyWellness** (`pronext.mywellness.com`). L'abbinamento fra le due anagrafiche
avviene **tramite l'indirizzo email**.

Il pagamento vero, la ricevuta e la contabilità restano su WIC: su MyWellness si
crea solo la controparte "vetrina", così il cliente se la ritrova subito
nell'app Technogym.

## Come funziona

1. Fai la vendita su Wellness in Cloud come sempre.
2. Quando la vendita risulta conclusa compare il pulsante **Sincronizza su
   Technogym**, con email e prodotti già letti. Compare **solo se almeno un
   prodotto della vendita è sincronizzabile**, cioè ha un abbinamento
   confermato o è marcato "chiedi sempre": il listino WIC ha centinaia di voci
   che su Technogym non devono finire, e senza questo filtro il pulsante
   comparirebbe ad ogni vendita. La vendita viene comunque passata al pannello:
   se lo apri dall'icona la trovi lì. Il motivo per cui il pulsante non è
   comparso è scritto nella traccia diagnostica (`data-tgs-diag`, campo
   `pulsante`).
3. Si apre il pannello laterale di Chrome: controlli email e abbinamento
   prodotto, e avvii. Il pulsante compare in basso a sinistra — dove la barra
   dei pulsanti del riepilogo vendita non arriva — e si può **trascinare**
   altrove: la posizione viene ricordata.
4. L'estensione apre una scheda MyWellness **in secondo piano**, cerca il
   cliente per email, va su Acquisti, crea l'acquisto del prodotto abbinato e
   lo conferma. Il pannello mostra ogni passo.
5. A fine lavoro la scheda si chiude da sola. Se qualcosa va storto **resta
   aperta e in primo piano** al punto in cui si è fermata, così puoi finire a mano.

Se il login su MyWellness manca, il lavoro si mette in pausa, ti porta sulla
scheda per farlo e riprende da solo appena sei dentro (attende fino a 5 minuti).

Il pulsante non è l'unica strada: cliccando l'icona dell'estensione si apre lo
stesso pannello, dove puoi inserire email e prodotto a mano.

## Installazione sulle postazioni

L'estensione è distribuita da sé, senza Chrome Web Store: un pacchetto firmato
(`.crx`) pubblicato su GitHub e una policy di Chrome che lo installa e lo tiene
aggiornato.

- pacchetto: `https://raw.githubusercontent.com/ilGenu/technogym-sync-dist/main/technogym-sync.crx`
- manifest di aggiornamento: `.../update.xml`
- ID estensione: `omhjkdfnkanejanndbdimcilimhbkphn` (fissato dalla chiave nel manifest)

**Su ogni postazione, una volta sola:**

- **macOS** — doppio clic su `technogym-sync-macos.mobileconfig`, poi
  *Impostazioni di sistema → Privacy e sicurezza → Profili* per completare
  l'installazione (serve la password di amministratore). Riavviare Chrome.
- **Windows** — tasto destro su `technogym-sync-windows.reg` → *Unisci*,
  confermando la richiesta di amministratore. Riavviare Chrome.

Chrome installa l'estensione da solo al riavvio. Essendo installata da policy,
l'utente non può disattivarla o rimuoverla: per toglierla si rimuove il profilo
(macOS) o la chiave di registro (Windows).

Se sulla postazione c'è ancora la versione caricata a mano in modalità
sviluppatore, **va rimossa prima**: ha lo stesso ID e le due installazioni
entrerebbero in conflitto.

### Configurazione governata dall'amministratore

I profili di installazione contengono anche **la configurazione** (abbinamenti,
ricetta, opzioni), presa da `configurazione-all-fit.json` al momento della
generazione. Sulle postazioni che li ricevono:

- la configurazione arriva dalla policy e ha la precedenza su tutto — funziona
  anche dove Chrome **non è collegato ad alcun account**, cioè dove la
  sincronizzazione non arriverebbe;
- la pagina Impostazioni diventa **di sola lettura**, con un avviso in cima:
  un operatore non può cambiare un abbinamento e propagarlo a tutti. Restano
  usabili solo i due riquadri di lettura dei listini, che sono un aiuto locale;
- il pannello non offre più "ricorda questo abbinamento", perché non avrebbe
  effetto.

Il computer di chi amministra **non installa il profilo**: lì la configurazione
resta modificabile ed è la sorgente da cui si esporta il file.

Per cambiare la configurazione di tutte le postazioni:

1. Impostazioni → *Esporta configurazione*, salvando su `configurazione-all-fit.json`;
2. `./strumenti/genera-profili.sh`;
3. distribuire i profili aggiornati (doppio clic / Unisci come la prima volta).

Lo stato "gestita/sola lettura" non viene mai salvato in locale: si ricava ad
ogni avvio. Togliendo il profilo da una postazione, questa torna modificabile.

### Pubblicare un aggiornamento

1. alza `"version"` in `manifest.json`;
2. `./strumenti/pacchettizza.sh` (rigenera `.crx` e `update.xml` in `dist/`);
3. carica i due file su GitHub, sostituendo i precedenti.

Le postazioni si aggiornano da sole entro qualche ora, o subito da
`chrome://extensions` premendo *Aggiorna*. Nessuna revisione, nessuno store.

La chiave privata `chiave-estensione.pem` **è l'identità dell'estensione**: se
si perde, le installazioni esistenti non ricevono più aggiornamenti e vanno
rifatte a mano su ogni postazione. Va tenuta al sicuro e fuori da git.

## Installazione manuale (sviluppo)

1. `chrome://extensions` → attiva **Modalità sviluppatore**.
2. **Carica estensione non pacchettizzata** → scegli la cartella `technogym-sync`.
3. Apri le **Impostazioni** dell'estensione e fai la calibrazione qui sotto.

## Stato della calibrazione

**Lato MyWellness: fatto e verificato sul portale vero** (20 agosto 2026, fino
alla creazione di un acquisto reale a 0 €). La ricetta predefinita contiene i
selettori veri, non ipotesi:

| Passo | Ancoraggio verificato |
|---|---|
| Ricerca cliente | `#quick-search` (id stabile; le classi MUI `jss…` cambiano ad ogni build) |
| Invio ricerca | Invio sintetico → `/search/advancedsearch` |
| Riga del risultato | `[role="button"].MuiListItem-root:not(.navigation-menu *)` — l'esclusione è indispensabile: le voci del menu laterale usano lo stesso componente |
| Sezione Acquisti | testo `acquisti` sulla panoramica |
| Pulsante `+` | pulsante icona accanto al titolo "Acquisti" (non ha etichetta né `data-*`) |
| Campo prodotto | `.MuiDialog-root input[placeholder="Cerca"]` — dentro la modale, per non scrivere nella ricerca globale che ha lo stesso placeholder |
| Card prodotto | ricerca **per testo** del nome, poi risalita alla card: dopo il filtro la griglia contiene celle segnaposto che rispondono allo stesso selettore strutturale, e la card vera sfuggiva |
| Identità cliente | la ricerca per email deve restituire **una sola** anagrafica (l'email stampata nella scheda è solo una conferma in più: su certi profili non c'è) |
| Conferma | pulsante **Attiva** (a totale zero non si passa dal pagamento) — scrive subito sul server, il SALVA della modale non serve |

Tre cose scoperte solo provandole, che sarebbero state altrimenti dei
fallimenti silenziosi:

- **il click va emesso al centro dell'elemento**, non sull'elemento: le card
  prodotto hanno l'`onClick` di React su un div interno senza classi stabili, e
  un click sul contenitore non lo raggiunge (gli eventi risalgono, non
  scendono). La card non entrava nel carrello e nulla lo segnalava;
- **la riga del risultato non contiene l'email** (mostra nome, data di nascita,
  tipo): abbinarla per email era impossibile. Ora si apre il primo risultato e
  **si verifica l'email sulla scheda** prima di toccare gli acquisti;
- **il lettore di listino** generalizzava la classe dell'elemento cliccato: sul
  listino vero avrebbe restituito 39 voci (nomi, tipi e date mescolati) invece
  di 13 prodotti. Ora individua il livello che si ripete e riscende in ogni riga.

Due controlli di sicurezza sono cablati nella ricetta: **l'email sulla scheda
deve corrispondere** a quella della vendita, e **il totale deve essere 0,00 €**
prima della conferma — se un abbinamento sbagliato puntasse a un prodotto con
prezzo, il portale mostrerebbe "Vai al pagamento" e il lavoro si ferma invece
di aprire un incasso vero.

Il listino MyWellness è già caricato (13 prodotti letti da Configurazione ›
Negozio › Prodotti).

**Lato Wellness in Cloud: da fare** — è il punto 3 qui sotto.

## Calibrazione

### 1. Listini
Impostazioni → *Listini e abbinamenti*. Apri la pagina prodotti di WIC, premi
**Leggi listino dalla pagina** e clicca **il nome di un prodotto**: l'estensione
riconosce tutti gli elementi simili e legge l'intero elenco. Quello MyWellness è
già presente e si può rileggere allo stesso modo.

### 2. Abbinamenti
**Proponi abbinamenti** accosta i due listini per somiglianza del nome —
funziona anche se i nomi non coincidono ("Abbonamento Open 12 mesi" ↔ "OPEN 12
MESI - Abbonamento"), e i numeri contano ("10 ingressi" non viene abbinato a
"20 ingressi"). Ogni proposta mostra la percentuale e **va confermata**: senza
conferma non viene mai usata in una sincronizzazione.

### 3. Rilevamento della vendita
**Verificato su una vendita reale** (20 agosto 2026). La vendita si conclude
con `POST https://api.wellness.incloud.it/{guid}/Sales/sales`, seguito da
`GET /Sales/{idVendita}/files/info`. Il pattern predefinito `sales/sales` con
metodi POST/PUT è quindi confermato, e il pulsante compare da solo.

Due cose che solo la vendita vera ha rivelato, entrambe già gestite:

- **il corpo del POST non contiene l'email del cliente** (570 byte, nessuna
  email) e nemmeno i nomi dei prodotti, solo identificativi. L'email viene
  quindi risolta tramite l'**id cliente**: l'estensione tiene una mappa
  `id → email` alimentata dalle risposte che il portale carica da solo quando
  apri la scheda (`Customers/preview/<id>`), e la interroga con l'id presente
  nell'URL `/WicSales/<id>`;
- **la prima email visibile nella pagina è quella dell'operatore**, in testata.
  Usarla come ripiego avrebbe registrato l'acquisto sull'anagrafica sbagliata:
  ora resta l'ultima spiaggia, marcata come inaffidabile e segnalata nel
  pannello ("Email letta dalla pagina, non dai dati della vendita").

I nomi dei prodotti si leggono dal riepilogo a schermo (le etichette
`label.v-label-text` del blocco che contiene "Totale"), scartando gli importi.

Le frasi di conclusione usate dal rilevamento di riserva sono quelle vere della
schermata: *"Vendita: salvata con successo"*, *"Pagamento: completato con
successo"*, *"Riepilogo vendita"*.

Se un domani il portale cambia, in Impostazioni → *Rilevamento vendita* la
**Diagnostica** elenca le chiamate osservate con l'indicazione di quali
contenevano un'email, e basta un click su *usa come pattern*.

### 4. Ricetta MyWellness
Già calibrata (vedi sopra). Se un domani Technogym cambia il frontend, il
pannello dirà su quale passo si è fermato: apri Impostazioni → *Ricetta
MyWellness*, tieni aperta la scheda sulla pagina giusta e premi **Cattura** sul
passo interessato per registrare il nuovo selettore.

Consiglio per il collaudo: in *Opzioni* attiva **mostra la scheda** e
**modalità prova** — l'estensione esegue tutto ma salta la conferma finale, così
vedi dove si inceppa senza creare acquisti veri.

## Configurazione su più computer

**Automatica.** Abbinamenti, ricetta, impostazioni di rilevamento e opzioni
viaggiano da soli fra i computer collegati allo **stesso account Chrome**, via
`chrome.storage.sync`. I **listini restano locali**: con 308 prodotti WIC la
configurazione completa pesa ~18.900 byte e supererebbe il limite di 8.192 byte
per voce; le parti condivise stanno in ~3,5 KB. Il listino si rilegge comunque
da una pagina in un click.

Due dettagli che rendono la cosa affidabile:

- **gli abbinamenti si fondono, non si sovrascrivono**: per lo stesso prodotto
  vince la modifica più recente, e quelli presenti su un solo computer si
  sommano. Senza questo, salvare da un computer rimasto indietro cancellava il
  lavoro fatto sull'altro;
- **riattivare la sincronizzazione dopo averla spenta forza sempre la fusione**,
  perché è il caso in cui il computer è più indietro di tutti.

In *Impostazioni → Sincronizzazione* ci sono l'interruttore (locale: non viene
mai sincronizzato), la data dell'ultimo allineamento e **Sincronizza adesso**.

### Perché serve la chiave nel manifest

`chrome.storage.sync` è legato all'**ID dell'estensione**. Un'estensione
caricata "non pacchettizzata" prende un ID diverso su ogni computer, quindi due
installazioni resterebbero due mondi separati. Per questo `manifest.json`
contiene un campo `key` con una chiave pubblica fissa: l'ID risulta lo stesso
ovunque — `omhjkdfnkanejanndbdimcilimhbkphn`.

La parte privata (`chiave-estensione.pem`) serve solo per impacchettare un
`.crx` ed è esclusa da git: non condividerla. Sui computer nuovi si copia la
cartella e si carica come non pacchettizzata, esattamente come sul primo.

**Export / Import** restano disponibili in Impostazioni: servono quando i
computer sono su account Chrome diversi, o per tenersi una copia di sicurezza
prima di modifiche importanti.

## Diagnostica quando qualcosa non va

Ogni chiamata riconosciuta come vendita lascia due tracce leggibili senza
strumenti particolari (nessun dato personale, solo la forma dei dati):

- in console: `[Sync WIC→Technogym] chiamata vendita rilevata: {…}`
- sull'elemento `<html>`, l'attributo `data-tgs-diag`.

Dicono se il corpo della risposta è arrivato (`tipoRes`, `chiaviRes`), se
l'email è stata trovata e **da dove** (`payload` = dai dati della vendita,
`pagina` = ripescata dal testo a schermo, meno affidabile), e quanti prodotti
sono stati estratti.

Due cose da ricordare prima di dare la colpa al codice:

- **i content script non entrano nelle schede già aperte**: dopo aver
  installato o ricaricato l'estensione va ricaricata anche la pagina;
- se il pulsante non compare affatto, guarda prima la console: un'eccezione nel
  content script lo impedisce senza dare altri segnali.

## Aggiornamenti e configurazione salvata

Ricetta e pattern di rilevamento hanno un numero di versione. Quando una nuova
versione dell'estensione ne porta di più recenti, quelli salvati vengono
aggiornati da soli — **tranne** se li hai modificati a mano dalle impostazioni:
in quel caso il tuo lavoro vince sempre (`recipeEdited` / `edited`), e per
tornare ai predefiniti c'è *ripristina ricetta predefinita*.

Serve perché la configurazione viene persistita per intero appena si tocca una
qualsiasi opzione (anche solo la spunta "modalità prova"): senza versione, la
ricetta di quel momento resterebbe congelata per sempre e nessuna correzione
successiva arriverebbe mai.

Le tue cose — abbinamenti, listini, opzioni — non vengono mai toccate.

## Limiti da conoscere

- **Dipende dal DOM dei due portali.** Se TeamSystem o Technogym cambiano il
  frontend, un passo può smettere di trovare il suo elemento: si ricalibra con
  *Cattura*, senza toccare il codice. Il pannello dice sempre su quale passo si
  è fermato.
- **Non usa API ufficiali.** L'Enterprise API Technogym non espone la creazione
  di un acquisto per un'anagrafica, e l'API di WIC è documentata solo di fatto
  (vedi `mywellness-access-bridge/README.md`). Qui si automatizza l'interfaccia
  con le credenziali che l'operatore ha già: nessuna password viene letta o
  memorizzata dall'estensione.
- **Scheda in secondo piano.** Chrome rallenta i timer nelle schede non attive.
  Le attese usano `MutationObserver`, che non viene rallentato, ma su lavori
  lunghi può servire qualche secondo in più. Se un portale si comporta in modo
  strano da nascosto, attiva *mostra la scheda*.
- **"Chiedi sempre"**: per i prodotti WIC generici che su MyWellness hanno più
  varianti (es. un unico *04 Check Up (singolo test)* contro sei *Checkup
  Singolo*), l'abbinamento non viene mai risolto da solo: il pannello chiede
  quale variante usare ad ogni vendita, con la spunta "ricorda" non
  preselezionata.
- **Il prodotto a 0 € deve esistere già** nel listino MyWellness: l'estensione
  lo seleziona, non lo crea.
- **Il pannello è la barra laterale di Chrome.** L'apertura è concessa solo
  dentro un gesto dell'utente, e il gesto si perde al primo `await`: per questo
  `sidePanel.open()` viene chiamata come primissima cosa alla ricezione del
  click, prima di leggere qualsiasi configurazione. La finestra a parte resta
  solo per chi la sceglie in *Opzioni → Interfaccia*.
- **Login su MyWellness**: la sessione del portale non viene ereditata da una
  scheda appena aperta, quindi una scheda nuova ripartirebbe dall'accesso ad
  ogni sincronizzazione. Per questo l'estensione **riusa una scheda MyWellness
  già aperta** quando la trova (opzione attiva di default): tienine una aperta
  e il login non viene più chiesto. In alternativa, spuntando *"Ricordami su
  questo dispositivo"* al momento dell'accesso la sessione dovrebbe durare
  oltre la singola scheda.
- **Il rilevamento a schermo è un ripiego, non il canale principale.** Produce
  solo l'email (nessun prodotto, perché non c'è un payload da leggere) ed è
  volutamente subordinato: non sovrascrive una rilevazione arrivata dalla
  chiamata API negli ultimi due minuti, e ignora il testo del pulsante iniettato
  dall'estensione — che contiene "Vendita completata" e altrimenti si
  auto-innescherebbe, degradando la vendita appena letta.
- **Più prodotti nella stessa vendita**: la ricetta viene ripetuta per ciascun
  prodotto abbinato. I prodotti senza abbinamento confermato vengono saltati e
  segnalati nel pannello.

## Struttura

```
manifest.json
src/
  lib/constants.js        tipi di messaggio e chiavi di storage
  lib/fuzzy.js            somiglianza fra nomi di prodotto
  lib/storage.js          configurazione + valori predefiniti (ricetta compresa)
  lib/dom.js              risoluzione dei target, attese, input compatibili SPA
  background/service-worker.js  instradamento messaggi, pannello, catturatore
  background/runner.js    esecuzione del lavoro sulla scheda MyWellness
  content/net-hook-main.js      intercetta fetch/XHR di WIC (sola lettura)
  content/wic-checkout.js       rileva la vendita e mostra il pulsante
  content/mywellness-agent.js   esegue i passi su MyWellness
  content/picker.js             cattura selettori e listini a click
  sidepanel/                    pannello di avanzamento
  options/                      impostazioni, abbinamenti, diagnostica
```
