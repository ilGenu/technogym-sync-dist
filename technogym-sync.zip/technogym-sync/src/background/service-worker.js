/* Service worker: instrada i messaggi, apre il pannello, avvia i lavori di
   sincronizzazione e gestisce il catturatore di selettori. */
importScripts('../lib/constants.js', '../lib/fuzzy.js', '../lib/storage.js', 'runner.js');

const { MSG, JOB_STATUS } = TGS;

const WIC_MATCHES = [
  'https://new.wellness.incloud.it/*',
  'https://app.wellnessincloud.it/*',
  'https://*.wellness.incloud.it/*'
];
const MW_MATCHES = ['https://pronext.mywellness.com/*'];

let currentJob = null;
let pendingSale = null;      // ultima vendita rilevata, in attesa nel pannello
let sourceTabId = null;

chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  scaricaConfigurazione();
  chrome.alarms.create('config-remota', { periodInMinutes: 60 });
});

chrome.runtime.onStartup.addListener(() => {
  scaricaConfigurazione();
  chrome.alarms.create('config-remota', { periodInMinutes: 60 });
});

chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === 'config-remota') scaricaConfigurazione();
});

/* Scarica la configurazione dall'indirizzo indicato dalla policy e la mette da
   parte in locale. Il file remoto è la sorgente di verità per le postazioni:
   aggiornarlo aggiorna tutte, senza ridistribuire nulla.

   Se il download fallisce (rete assente, file momentaneamente rotto) resta
   valida l'ultima copia scaricata: meglio una configurazione vecchia che
   nessuna. */
async function scaricaConfigurazione() {
  try {
    const gestita = await TGS.storage.leggiGestita();
    if (!gestita || !gestita.url) return { ok: false, motivo: 'nessun indirizzo configurato' };

    const res = await fetch(gestita.url, { cache: 'no-cache' });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const testo = await res.text();
    const cfg = JSON.parse(testo);
    if (!cfg || typeof cfg !== 'object' || !cfg.mywellness) {
      throw new Error('il file non sembra una configurazione valida');
    }

    await chrome.storage.local.set({
      [TGS.REMOTE_KEY]: { cfg, scaricataIl: Date.now(), url: gestita.url }
    });
    console.log('[Sync WIC→Technogym] configurazione aggiornata da', gestita.url);
    return { ok: true, abbinamenti: (cfg.mappings || []).length, scaricataIl: Date.now() };
  } catch (e) {
    console.warn('[Sync WIC→Technogym] configurazione remota non aggiornata:', e && e.message);
    return { ok: false, motivo: String(e && e.message || e) };
  }
}

// Un port aperto dal content script MyWellness tiene sveglio il service worker
// per tutta la durata del lavoro.
chrome.runtime.onConnect.addListener((port) => {
  if (port.name === 'tgs-mw') port.onMessage.addListener(() => {});
});

/* L'apertura del pannello laterale è concessa solo dentro un gesto
   dell'utente, e il gesto si perde al primo `await`: la versione precedente
   leggeva prima la configurazione e chiamava `open()` dopo, quindi Chrome la
   rifiutava sempre e si finiva sulla finestra a parte. Qui `open()` è la
   PRIMA cosa che viene chiamata, in modo sincrono. */
function openPanel(tabId) {
  try {
    if (tabId != null) {
      chrome.sidePanel.setOptions({ tabId, path: 'src/sidepanel/panel.html', enabled: true });
    }
    const p = chrome.sidePanel.open(tabId != null ? { tabId } : {});
    if (p && typeof p.catch === 'function') p.catch((err) => fallbackFinestra(err));
    return true;
  } catch (err) {
    fallbackFinestra(err);
    return false;
  }
}

/* Ripiego usato solo se il pannello laterale viene rifiutato E l'utente ha
   scelto esplicitamente la modalità "finestra": chi vuole solo la barra
   laterale non deve vedersi aprire finestre a sorpresa. */
async function fallbackFinestra(err) {
  const cfg = await TGS.storage.getConfig();
  if (cfg.options.panelMode !== 'window') {
    console.warn('[Sync WIC→Technogym] pannello laterale non apribile:', err && err.message);
    return;
  }
  await chrome.windows.create({
    url: chrome.runtime.getURL('src/sidepanel/panel.html'),
    type: 'popup', width: 460, height: 640
  });
}

async function startSync({ sale, overrides }, tabId) {
  if (currentJob && currentJob.status === JOB_STATUS.RUNNING) {
    return { ok: false, error: 'una sincronizzazione è già in corso' };
  }
  const cfg = await TGS.storage.getConfig();
  const { items, unmapped } = TGS.runner.resolveItems(cfg, sale, overrides);
  if (!sale.email) return { ok: false, error: 'email del cliente mancante' };
  if (!items.length) {
    return {
      ok: false,
      error: 'nessun prodotto abbinato' + (unmapped.length ? ': ' + unmapped.join(', ') : ''),
      unmapped
    };
  }
  currentJob = new TGS.runner.Job(cfg, sale, items, tabId || sourceTabId);
  currentJob.run();       // volutamente non atteso: l'avanzamento arriva via messaggi
  return { ok: true, job: currentJob.snapshot(), unmapped };
}

/* ---------- catturatore di selettori ---------- */

async function findTab(site) {
  const patterns = site === 'mw' ? MW_MATCHES : WIC_MATCHES;
  for (const url of patterns) {
    const tabs = await chrome.tabs.query({ url });
    if (tabs.length) return tabs[0];
  }
  return null;
}

async function startPicker({ site, mode }) {
  const tab = await findTab(site);
  if (!tab) {
    return {
      ok: false,
      error: site === 'mw'
        ? 'apri prima una scheda su pronext.mywellness.com'
        : 'apri prima una scheda su Wellness in Cloud'
    };
  }
  await chrome.tabs.update(tab.id, { active: true });
  await chrome.windows.update(tab.windowId, { focused: true }).catch(() => {});
  await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ['src/content/picker.css'] });
  await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['src/content/picker.js'] });
  await chrome.tabs.sendMessage(tab.id, { type: MSG.START_PICKER, mode });
  return { ok: true, tabId: tab.id, url: tab.url };
}

/* ---------- instradamento messaggi ---------- */

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    switch (msg.type) {
      case MSG.SALE_DETECTED:
        pendingSale = msg.sale;
        sourceTabId = sender.tab && sender.tab.id;
        chrome.runtime.sendMessage({ type: MSG.SALE_DETECTED, sale: pendingSale }).catch(() => {});
        return sendResponse({ ok: true });

      case MSG.OPEN_PANEL:
        pendingSale = msg.sale || pendingSale;
        sourceTabId = (sender.tab && sender.tab.id) || sourceTabId;
        openPanel(sourceTabId);   // sincrono: vedi openPanel()
        chrome.runtime.sendMessage({ type: MSG.SALE_DETECTED, sale: pendingSale }).catch(() => {});
        return sendResponse({ ok: true });

      case MSG.GET_STATE: {
        const cfg = await TGS.storage.getConfig();
        const stored = await chrome.storage.local.get(TGS.JOB_KEY);
        return sendResponse({
          ok: true,
          sale: pendingSale,
          job: currentJob ? currentJob.snapshot() : stored[TGS.JOB_KEY] || null,
          config: cfg
        });
      }

      case MSG.START_SYNC:
        return sendResponse(await startSync(msg, sourceTabId));

      case MSG.CANCEL_SYNC:
        if (currentJob) currentJob.cancelled = true;
        return sendResponse({ ok: true });

      case MSG.FOCUS_WORK_TAB:
        if (currentJob && currentJob.workTabId != null) {
          await chrome.tabs.update(currentJob.workTabId, { active: true }).catch(() => {});
          const t = await chrome.tabs.get(currentJob.workTabId).catch(() => null);
          if (t) await chrome.windows.update(t.windowId, { focused: true }).catch(() => {});
        }
        return sendResponse({ ok: true });

      case MSG.REFRESH_REMOTE:
        return sendResponse(await scaricaConfigurazione());

      case MSG.START_PICKER:
        return sendResponse(await startPicker(msg));

      case MSG.PICKER_RESULT:
        // Rilancio verso la pagina delle impostazioni, che è in attesa.
        chrome.runtime.sendMessage({ type: MSG.PICKER_RESULT, payload: msg.payload }).catch(() => {});
        return sendResponse({ ok: true });

      case MSG.SCRAPE_LIST: {
        const res = await startPicker({ site: msg.site, mode: 'catalog' });
        return sendResponse(res);
      }

      default:
        return sendResponse({ ok: false, error: 'messaggio non gestito: ' + msg.type });
    }
  })().catch((err) => sendResponse({ ok: false, error: String(err && err.message || err) }));
  return true; // risposta asincrona
});
