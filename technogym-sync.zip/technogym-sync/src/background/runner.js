/* Esecuzione della "finta" vendita su MyWellness: apre una scheda di lavoro,
   la pilota un passo alla volta e riferisce l'avanzamento al pannello. */
(function (root) {
  const TGS = (root.TGS = root.TGS || {});
  const { MSG, JOB_STATUS } = TGS;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  function waitTabComplete(tabId, timeoutMs = 45000) {
    return new Promise((resolve, reject) => {
      const t0 = Date.now();
      let iv = null;
      const done = () => {
        chrome.tabs.onUpdated.removeListener(onUpd);
        clearInterval(iv);
      };
      const onUpd = (id, info) => {
        if (id === tabId && info.status === 'complete') { done(); resolve(); }
      };
      chrome.tabs.onUpdated.addListener(onUpd);
      iv = setInterval(async () => {
        try {
          const tab = await chrome.tabs.get(tabId);
          if (tab.status === 'complete') { done(); resolve(); }
        } catch (e) { done(); reject(new Error('scheda di lavoro chiusa')); }
        if (Date.now() - t0 > timeoutMs) { done(); reject(new Error('caricamento pagina troppo lento')); }
      }, 500);
    });
  }

  async function pingTab(tabId, attempts = 30) {
    for (let i = 0; i < attempts; i++) {
      try {
        const res = await chrome.tabs.sendMessage(tabId, { type: MSG.MW_PING });
        if (res && res.ok) return res;
      } catch (_) { /* content script non ancora pronto */ }
      await sleep(300);
    }
    throw new Error('la pagina MyWellness non risponde (content script non iniettato?)');
  }

  function fillTemplate(value, vars) {
    if (typeof value !== 'string') return value;
    return value.replace(/\{\{(\w+)\}\}/g, (_, k) => (vars[k] == null ? '' : String(vars[k])));
  }

  /** Espande la ricetta in una lista piatta di passi, uno per prodotto. */
  function buildSteps(cfg, sale, items) {
    const steps = [];
    items.forEach((item, idx) => {
      cfg.mywellness.recipe.forEach((raw) => {
        // Per il secondo prodotto in poi si riparte dalla ricerca anagrafica:
        // il portale resta sulla scheda del cliente, quindi si salta l'apertura.
        if (idx > 0 && (raw.id === 'open' || raw.id === 'login')) return;
        steps.push({
          key: `${idx}:${raw.id}`,
          productIndex: idx,
          label: items.length > 1 ? `[${item.mwName}] ${raw.label}` : raw.label,
          status: 'pending',
          detail: '',
          def: Object.assign({}, raw, {
            value: fillTemplate(raw.value, {
              email: sale.email,
              mwProduct: item.mwName,
              wicProduct: item.wicName
            })
          })
        });
      });
    });
    return steps;
  }

  /** Abbina i prodotti della vendita WIC ai prodotti MyWellness configurati. */
  function resolveItems(cfg, sale, overrides) {
    const items = [];
    const unmapped = [];
    for (const p of sale.products || []) {
      const forced = overrides && overrides[p.name];
      const map = forced ? { mwName: forced } : TGS.storage.resolveMapping(cfg, p.name);
      if (map && map.mwName) items.push({ wicName: p.name, mwName: map.mwName, qty: p.qty || 1 });
      else unmapped.push(p.name);
    }
    return { items, unmapped };
  }

  class Job {
    constructor(cfg, sale, items, sourceTabId) {
      this.id = 'job-' + Date.now();
      this.cfg = cfg;
      this.sale = sale;
      this.items = items;
      this.sourceTabId = sourceTabId;
      this.steps = buildSteps(cfg, sale, items);
      this.status = JOB_STATUS.RUNNING;
      this.error = null;
      this.workTabId = null;
      this.reusedTab = false;
      this.cancelled = false;
      this.startedAt = Date.now();
    }

    snapshot() {
      return {
        id: this.id,
        status: this.status,
        error: this.error,
        sale: this.sale,
        items: this.items,
        workTabId: this.workTabId,
        startedAt: this.startedAt,
        steps: this.steps.map((s) => ({
          key: s.key, label: s.label, status: s.status, detail: s.detail
        }))
      };
    }

    broadcast() {
      const payload = { type: MSG.JOB_UPDATE, job: this.snapshot() };
      chrome.runtime.sendMessage(payload).catch(() => {});
      chrome.storage.local.set({ [TGS.JOB_KEY]: payload.job }).catch(() => {});
    }

    setStep(step, status, detail) {
      step.status = status;
      if (detail != null) step.detail = String(detail).slice(0, 300);
      this.broadcast();
    }

    /* Se c'è già una scheda MyWellness aperta la si riusa, invece di aprirne
       una nuova. Oltre a lasciare il browser più pulito, evita il login: la
       sessione del portale non viene ereditata da una scheda appena creata,
       quindi ogni scheda nuova ripartirebbe dalla schermata di accesso. */
    async openWorkTab() {
      const url = this.cfg.mywellness.startUrl || TGS.MW_ORIGIN + '/';

      if (this.cfg.options.reuseTab !== false) {
        const aperte = await chrome.tabs.query({ url: TGS.MW_ORIGIN + '/*' });
        const utile = aperte.find((t) => !t.discarded);
        if (utile) {
          this.workTabId = utile.id;
          this.reusedTab = true;
          this.broadcast();
          try {
            await pingTab(utile.id, 6);
            return;
          } catch (_) {
            // scheda inerte (sospesa o senza content script): si prosegue
            // aprendone una nuova, sotto.
            this.workTabId = null;
            this.reusedTab = false;
          }
        }
      }

      const tab = await chrome.tabs.create({ url, active: !!this.cfg.options.showWorkTab });
      this.workTabId = tab.id;
      this.broadcast();
      await waitTabComplete(tab.id);
      await pingTab(tab.id);
    }

    async runStepDef(def) {
      if (def.action === 'navigate') {
        await chrome.tabs.update(this.workTabId, { url: def.value });
        await waitTabComplete(this.workTabId);
        await pingTab(this.workTabId);
        return { navigated: def.value };
      }
      const res = await chrome.tabs.sendMessage(this.workTabId, { type: MSG.MW_RUN_STEP, step: def });
      if (!res) throw new Error('nessuna risposta dalla pagina');
      if (!res.ok) throw new Error(res.error || 'passo fallito');
      return res.result || {};
    }

    /** Il portale ha mostrato il login: porta l'utente sulla scheda e attende. */
    async waitForLogin(step) {
      this.status = JOB_STATUS.NEEDS_LOGIN;
      this.setStep(step, 'waiting', 'serve il login su MyWellness: la scheda è stata aperta');
      await chrome.tabs.update(this.workTabId, { active: true });
      try {
        const tab = await chrome.tabs.get(this.workTabId);
        await chrome.windows.update(tab.windowId, { focused: true });
      } catch (_) { /* finestra non disponibile */ }

      const deadline = Date.now() + 5 * 60 * 1000;
      while (Date.now() < deadline) {
        if (this.cancelled) throw new Error('annullato');
        await sleep(2000);
        try {
          await pingTab(this.workTabId, 3);
          const res = await this.runStepDef({ action: 'requireLogin' });
          if (!res.needsLogin) {
            this.status = JOB_STATUS.RUNNING;
            if (!this.cfg.options.showWorkTab && this.sourceTabId) {
              await chrome.tabs.update(this.sourceTabId, { active: true }).catch(() => {});
            }
            return;
          }
        } catch (_) { /* pagina in navigazione: riprova */ }
      }
      throw new Error('login non completato entro 5 minuti');
    }

    async run() {
      try {
        await this.openWorkTab();

        for (const step of this.steps) {
          if (this.cancelled) throw new Error('annullato');

          // In modalità prova si salta la conferma finale e anche la verifica
          // dell'esito, che senza conferma fallirebbe sempre facendo sembrare
          // fallita una prova andata bene.
          if (this.cfg.options.dryRun && (step.def.confirmStep || step.def.skipOnDryRun)) {
            this.setStep(step, 'skipped', 'saltato: modalità prova attiva');
            continue;
          }

          this.setStep(step, 'running');
          try {
            const res = await this.runStepDef(step.def);
            if (step.def.action === 'requireLogin' && res.needsLogin) {
              await this.waitForLogin(step);
              this.setStep(step, 'done', 'login effettuato');
              continue;
            }
            this.setStep(step, 'done', summarize(res));
          } catch (err) {
            if (step.def.optional) {
              this.setStep(step, 'skipped', 'non trovato (passo opzionale): ' + err.message);
              continue;
            }
            throw err;
          }
        }

        this.status = JOB_STATUS.DONE;
        this.broadcast();
        // Si chiude solo la scheda aperta da noi: quella dell'utente resta.
        if (!this.cfg.options.showWorkTab && !this.reusedTab) {
          await chrome.tabs.remove(this.workTabId).catch(() => {});
          this.workTabId = null;
          this.broadcast();
        }
      } catch (err) {
        this.status = this.cancelled ? JOB_STATUS.CANCELLED : JOB_STATUS.FAILED;
        this.error = String(err && err.message || err);
        // In caso di errore la scheda resta aperta: serve per capire dove si è
        // fermato e per completare a mano.
        if (this.workTabId != null) {
          await chrome.tabs.update(this.workTabId, { active: true }).catch(() => {});
        }
        this.broadcast();
      }
    }
  }

  function summarize(res) {
    if (!res || typeof res !== 'object') return '';
    if (res.picked) return `scelto: ${res.picked}${res.score != null ? ' (' + res.score + ')' : ''}`;
    if (res.filled) return `scritto: ${res.filled}`;
    if (res.clicked) return `cliccato: ${res.clicked}`;
    if (res.navigated) return res.navigated;
    if (res.text) return res.text;
    return '';
  }

  TGS.runner = { Job, resolveItems, buildSteps, waitTabComplete, pingTab };
})(globalThis);
