/* Content script su pronext.mywellness.com: esegue un passo alla volta della
   "ricetta" inviata dal service worker e ne riferisce l'esito.

   Gira in tutti i frame. Regola per evitare risposte contraddittorie quando la
   pagina ha degli iframe: i sotto-frame rispondono SOLO se il passo riesce,
   il frame principale risponde sempre (anche in caso di errore). */
(function () {
  'use strict';

  const { MSG } = TGS;
  const D = TGS.dom;
  const isTop = window.top === window;

  let config = null;
  TGS.storage.getConfig().then((c) => { config = c; });

  // Un port aperto tiene sveglio il service worker mentre il lavoro è in corso.
  if (isTop) {
    try {
      const port = chrome.runtime.connect({ name: 'tgs-mw' });
      const beat = setInterval(() => {
        try { port.postMessage({ t: 'beat' }); } catch (_) { clearInterval(beat); }
      }, 20000);
      port.onDisconnect.addListener(() => clearInterval(beat));
    } catch (_) { /* estensione ricaricata */ }
  }

  function timeout(step) {
    return step.timeoutMs || (config && config.options.stepTimeoutMs) || 20000;
  }

  async function runStep(step) {
    const t = timeout(step);

    switch (step.action) {
      case 'requireLogin': {
        const cfg = config || (config = await TGS.storage.getConfig());
        const loggedOut = D.resolve(cfg.mywellness.loggedOut);
        if (loggedOut) return { needsLogin: true };
        return { needsLogin: false };
      }

      case 'waitFor': {
        await D.waitFor(step.target, t);
        return { found: true };
      }

      case 'waitGone': {
        await D.waitFor(step.target, t, { gone: true });
        return { gone: true };
      }

      case 'click': {
        await D.waitFor(step.target, t);
        const el = D.resolveClickable(step.target);
        if (!el) throw new Error('elemento non cliccabile');
        D.clickEl(el);
        return { clicked: D.ownText(el).slice(0, 60) || el.tagName };
      }

      case 'fill': {
        const el = await D.waitFor(step.target, t);
        if (!('value' in el)) throw new Error('il target non è un campo di testo');
        D.setValue(el, step.value == null ? '' : String(step.value));
        return { filled: String(step.value) };
      }

      case 'pressKey': {
        const el = D.resolve(step.target) || document.activeElement;
        if (!el) throw new Error('nessun campo su cui premere il tasto');
        D.pressKey(el, step.value || 'Enter');
        return { key: step.value || 'Enter' };
      }

      case 'pickFromList': {
        /* Selezione in tre tempi, dal più preciso al più robusto.

           Serve perché la griglia dei prodotti di MyWellness, dopo il filtro,
           contiene anche celle vuote che rispondono allo stesso selettore
           strutturale: cercare solo lì faceva fallire il passo con la card
           giusta bene in vista. */

        // 1. attende che il testo cercato compaia davvero (la lista si
        //    ridisegna dopo il filtro, e all'inizio ci sono solo i segnaposto)
        try {
          await D.waitFor({ textContains: step.value }, Math.min(t, 8000));
        } catch (_) { /* può non comparire: si prova comunque sotto */ }

        // 2. la lista configurata
        let hit = D.pickBest(step.target, step.value, step.minScore || 0.45);

        // 3. ripiego: si cerca il testo ovunque e si risale alla card
        if (!hit) {
          // Niente 'label' qui: cliccare un'etichetta può azionare il controllo
          // a cui è associata invece della card. Si sale al contenitore vero.
          const CARD = '.MuiGrid-item, [role="button"], [role="option"], .MuiCard-root, li, tr';
          const trovati = D.resolveAll({ textContains: step.value });
          if (trovati.length) {
            const el = trovati[0];
            hit = { el: el.closest(CARD) || el, score: 1, perTesto: true };
          }
        }

        if (!hit) {
          // Messaggio utile a capire: cosa ha visto, non solo che ha fallito.
          const viste = D.resolveAll(step.target).slice(0, 6).map((e) => {
            const testo = D.ownText(e).slice(0, 40);
            const cls = (e.className || '').toString().replace(/jss\d+/g, '').trim().slice(0, 40);
            return testo ? '"' + testo + '"' : '(vuoto: ' + e.tagName.toLowerCase() + ' ' + cls + ')';
          });
          throw new Error('nessuna voce corrisponde a "' + step.value + '"' +
            (viste.length ? ' — viste: ' + viste.join(', ') : ' — nessun elemento nella lista'));
        }

        /* Clic con verifica e ritentativo. Il clic può cadere su una card che
           React ridisegna subito dopo il filtro: l'elemento resta staccato dal
           documento e la selezione non avviene, senza alcun errore. Se il passo
           dichiara un `confirm`, si controlla che compaia davvero e in caso
           contrario si ripete il clic su un elemento appena risolto. */
        const tentativi = step.attempts || (step.confirm ? 3 : 1);
        let ultimo = hit;
        for (let i = 0; i < tentativi; i++) {
          if (i > 0) {
            const ancora = D.pickBest(step.target, step.value, step.minScore || 0.45) ||
              (() => {
                const CARD = '.MuiGrid-item, [role="button"], [role="option"], .MuiCard-root, li, tr';
                const t = D.resolveAll({ textContains: step.value });
                return t.length ? { el: t[0].closest(CARD) || t[0], score: 1 } : null;
              })();
            if (!ancora) break;
            ultimo = ancora;
          }
          const bersaglio = ultimo.el.matches(D.CLICKABLE)
            ? ultimo.el
            : (ultimo.el.closest(D.CLICKABLE) || ultimo.el);
          D.clickEl(bersaglio);

          if (!step.confirm) break;
          try {
            await D.waitFor(step.confirm, 3000);
            return {
              picked: D.ownText(ultimo.el).slice(0, 80) || step.value,
              score: Number(ultimo.score.toFixed(2)),
              via: ultimo.perTesto ? 'testo' : 'lista',
              tentativi: i + 1
            };
          } catch (_) { /* non ha attecchito: si riprova */ }
        }

        if (step.confirm) {
          throw new Error('il prodotto è stato cliccato ma non risulta selezionato ' +
            'dopo ' + tentativi + ' tentativi');
        }
        return {
          picked: D.ownText(ultimo.el).slice(0, 80) || step.value,
          score: Number(ultimo.score.toFixed(2)),
          via: ultimo.perTesto ? 'testo' : 'lista'
        };
      }

      case 'assertCount': {
        // Quante voci corrispondono al target: serve a verificare che la
        // ricerca per email abbia trovato una e una sola anagrafica.
        const atteso = step.value == null ? 1 : Number(step.value);
        try {
          await D.waitFor(step.target, t);
        } catch (_) { /* zero risultati: lo dice il messaggio qui sotto */ }
        const n = D.resolveAll(step.target).length;
        if (n !== atteso) {
          throw new Error(
            n === 0
              ? 'nessuna anagrafica trovata con questa email'
              : `trovate ${n} anagrafiche con questa email: va scelta a mano`
          );
        }
        return { conteggio: n };
      }

      case 'assertText': {
        await D.waitFor(step.target, t);
        return { ok: true };
      }

      case 'extractText': {
        const el = await D.waitFor(step.target, t);
        return { text: D.ownText(el).slice(0, 200) };
      }

      case 'sleep': {
        const ms = Number(step.value) || 500;
        await new Promise((r) => setTimeout(r, ms));
        return { slept: ms };
      }

      default:
        throw new Error('azione sconosciuta: ' + step.action);
    }
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === MSG.MW_PING) {
      if (isTop) sendResponse({ ok: true, url: location.href, title: document.title });
      return isTop;
    }

    if (msg.type === MSG.MW_RUN_STEP) {
      runStep(msg.step).then(
        (result) => sendResponse({ ok: true, result }),
        (err) => {
          // Nei sotto-frame il fallimento resta silenzioso: risponde il frame
          // principale, così un iframe che non contiene l'elemento non fa
          // fallire un passo che invece è riuscito altrove.
          if (isTop) sendResponse({ ok: false, error: String(err && err.message || err) });
        }
      );
      return true;
    }
    return false;
  });
})();
