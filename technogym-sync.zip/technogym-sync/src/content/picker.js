/* Catturatore di selettori: iniettato su richiesta dalle impostazioni.
   Evidenzia l'elemento sotto il mouse e, al click, restituisce un target
   utilizzabile nella ricetta — oppure l'intero elenco di elementi simili
   (per leggere un listino da una pagina prodotti).

   Gira nello stesso "isolated world" dei content script dell'estensione,
   quindi TGS.dom è già disponibile. */
(function () {
  if (window.__tgsPickerLoaded) return;
  window.__tgsPickerLoaded = true;

  const D = TGS.dom;
  let active = false;
  let mode = 'selector';
  let box = null;
  let label = null;
  let current = null;

  function ui() {
    if (box) return;
    box = document.createElement('div');
    box.className = 'tgs-pick-box';
    label = document.createElement('div');
    label.className = 'tgs-pick-label';
    document.body.append(box, label);
  }

  function highlight(el) {
    ui();
    const r = el.getBoundingClientRect();
    Object.assign(box.style, {
      left: r.left + 'px', top: r.top + 'px',
      width: r.width + 'px', height: r.height + 'px', display: 'block'
    });
    const count = mode === 'catalog' ? D.similarElements(el).length : 0;
    label.textContent = mode === 'catalog'
      ? `${count} elementi simili · clicca per leggere il listino · Esc annulla`
      : `${el.tagName.toLowerCase()} · clicca per catturare · Esc annulla`;
    Object.assign(label.style, {
      left: r.left + 'px',
      top: Math.max(0, r.top - 24) + 'px',
      display: 'block'
    });
  }

  function describe(el) {
    const target = { css: D.cssPath(el) };
    const text = D.ownText(el);
    if (text && text.length <= 60) target.textContent = text;
    const ph = el.getAttribute && el.getAttribute('placeholder');
    if (ph) target.placeholder = ph;
    const aria = el.getAttribute && (el.getAttribute('aria-label') || el.getAttribute('title'));
    if (aria) target.aria = aria;
    return target;
  }

  function onMove(e) {
    if (!active) return;
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (!el || el === box || el === label) return;
    current = el;
    highlight(el);
  }

  function finish(payload) {
    stop();
    chrome.runtime.sendMessage({ type: TGS.MSG.PICKER_RESULT, payload }).catch(() => {});
  }

  function onClick(e) {
    if (!active) return;
    e.preventDefault();
    e.stopPropagation();
    const el = current || document.elementFromPoint(e.clientX, e.clientY);
    if (!el) return;

    if (mode === 'catalog') {
      const items = D.similarElements(el);
      const names = items
        .map((n) => D.ownText(n).trim())
        .filter((t) => t && t.length <= 120);
      finish({
        mode, url: location.href,
        sampleCss: D.cssPath(el),
        itemCss: itemSelector(el),
        names: Array.from(new Set(names))
      });
    } else {
      finish({ mode, url: location.href, target: describe(el) });
    }
  }

  function itemSelector(el) {
    const cls = Array.from(el.classList).filter((c) => !/\d{3,}/.test(c)).slice(0, 2);
    return el.tagName.toLowerCase() + (cls.length ? '.' + cls.join('.') : '');
  }

  function onKey(e) {
    if (e.key === 'Escape') {
      e.preventDefault();
      finish({ mode, cancelled: true });
    }
  }

  function start(m) {
    mode = m || 'selector';
    active = true;
    document.addEventListener('mousemove', onMove, true);
    document.addEventListener('click', onClick, true);
    document.addEventListener('keydown', onKey, true);
    window.focus();
  }

  function stop() {
    active = false;
    document.removeEventListener('mousemove', onMove, true);
    document.removeEventListener('click', onClick, true);
    document.removeEventListener('keydown', onKey, true);
    box && (box.style.display = 'none');
    label && (label.style.display = 'none');
  }

  chrome.runtime.onMessage.addListener((msg, _s, sendResponse) => {
    if (msg.type === TGS.MSG.START_PICKER) {
      start(msg.mode);
      sendResponse({ ok: true });
      return true;
    }
    return false;
  });
})();
