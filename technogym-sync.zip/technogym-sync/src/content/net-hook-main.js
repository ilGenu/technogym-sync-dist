/* Eseguito nel MAIN world della pagina Wellness in Cloud, a document_start.
   Intercetta fetch/XHR in sola lettura e rilancia un riassunto al content
   script isolato via window.postMessage. Non modifica né blocca nulla:
   se qualcosa va storto, la chiamata originale prosegue comunque.

   Serve perché il portale è una SPA: la vendita conclusa si riconosce molto
   più affidabilmente dalla chiamata API che dal DOM. */
(function () {
  const TAG = 'tgs-net';
  const MAX_BODY = 200000;

  function post(evt) {
    try {
      window.postMessage({ source: TAG, payload: evt }, '*');
    } catch (_) { /* payload non clonabile: si ignora */ }
  }

  function parse(text) {
    if (typeof text !== 'string' || !text || text.length > MAX_BODY) return null;
    const t = text.trim();
    if (!t || (t[0] !== '{' && t[0] !== '[')) return null;
    try { return JSON.parse(t); } catch (_) { return null; }
  }

  function bodyToText(body) {
    if (!body) return null;
    if (typeof body === 'string') return body;
    if (body instanceof URLSearchParams) return body.toString();
    return null; // FormData/Blob/stream: non li leggiamo
  }

  const origFetch = window.fetch;
  if (typeof origFetch === 'function') {
    window.fetch = function (input, init) {
      const url = typeof input === 'string' ? input : (input && input.url) || '';
      const method = ((init && init.method) || (input && input.method) || 'GET').toUpperCase();
      const reqBody = parse(bodyToText(init && init.body));
      return origFetch.apply(this, arguments).then((res) => {
        try {
          const ct = res.headers.get('content-type') || '';
          if (ct.includes('json')) {
            res.clone().text().then((txt) => {
              post({ url, method, status: res.status, at: Date.now(), req: reqBody, res: parse(txt) });
            }, () => {});
          } else {
            post({ url, method, status: res.status, at: Date.now(), req: reqBody, res: null });
          }
        } catch (_) { /* niente */ }
        return res;
      });
    };
  }

  const origOpen = XMLHttpRequest.prototype.open;
  const origSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (method, url) {
    this.__tgs = { method: String(method || 'GET').toUpperCase(), url: String(url || '') };
    return origOpen.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function (body) {
    const info = this.__tgs;
    if (info) {
      info.req = parse(bodyToText(body));
      this.addEventListener('load', function () {
        let resBody = null;
        try {
          resBody = this.responseType === '' || this.responseType === 'text'
            ? parse(this.responseText)
            : (this.responseType === 'json' ? this.response : null);
        } catch (_) { /* niente */ }
        post({ url: info.url, method: info.method, status: this.status, at: Date.now(), req: info.req, res: resBody });
      });
    }
    return origSend.apply(this, arguments);
  };
})();
