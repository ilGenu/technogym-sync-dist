/* Content script su Wellness in Cloud.
   1. ascolta le chiamate API intercettate da net-hook-main.js;
   2. riconosce la vendita conclusa (chiamata API o testo a schermo);
   3. estrae email cliente + prodotti;
   4. mostra il pulsante "Sincronizza su Technogym". */
(function () {
  // In modalità non-strict un'assegnazione a una variabile mai dichiarata crea
  // una globale silenziosa: è così che la mancanza di queste dichiarazioni è
  // passata inosservata fino alla prova sul portale. Meglio fallire subito.
  'use strict';

  const { MSG } = TGS;
  const EMAIL_RE = TGS.sale.EMAIL_RE;

  const CTA_ID = 'tgs-cta';
  const NOTICE_ID = 'tgs-notice';
  const POS_KEY = 'tgsCtaPos';   // chiave a sé: non tocca la configurazione
  let posizioneCta = null;
  let config = null;
  let contestoMorto = false;
  let lastSale = null;
  const netLog = [];

  /* Quando l'estensione viene ricaricata o aggiornata, i content script già
     iniettati restano vivi ma perdono l'accesso alle API: ogni chiamata
     chrome.* lancia "Extension context invalidated". Non è una promise
     rifiutata, quindi .catch() NON basta: senza questa protezione l'eccezione
     interrompeva il rilevamento un attimo prima di mostrare il pulsante, e
     l'utente vedeva semplicemente... niente. */
  function contestoVivo() {
    try { return !!(chrome.runtime && chrome.runtime.id); } catch (_) { return false; }
  }

  function segnalaContestoMorto() {
    if (contestoMorto) return;
    contestoMorto = true;
    try { domObserver.disconnect(); } catch (_) { /* già disconnesso */ }
    mostraAvviso('Estensione aggiornata: ricarica la pagina per riattivare la sincronizzazione.');
  }

  function inviaAlBackground(msg) {
    try {
      const p = chrome.runtime.sendMessage(msg);
      if (p && typeof p.catch === 'function') p.catch(() => {});
      return true;
    } catch (_) {
      segnalaContestoMorto();
      return false;
    }
  }

  function salvaInStorage(obj) {
    try {
      const p = chrome.storage.local.set(obj);
      if (p && typeof p.catch === 'function') p.catch(() => {});
    } catch (_) {
      segnalaContestoMorto();
    }
  }

  /* Il POST che conclude la vendita NON contiene l'email del cliente (verificato
     su una vendita reale: corpo di 570 byte, nessuna email). Ripiegare sulla
     prima email visibile nella pagina è pericoloso: in testata c'è quella
     dell'operatore, e si finirebbe per registrare l'acquisto sulla persona
     sbagliata.

     Si tiene quindi una mappa id-cliente → email, riempita con le risposte che
     il portale carica da solo quando si apre la scheda del cliente
     (`Customers/preview/<id>` e simili), e la si interroga con l'id che sta
     nell'URL della pagina di vendita (`/WicSales/<id>`). */
  const emailPerCliente = Object.create(null);
  const RE_CLIENTE_URL = /\/Customers\/(?:preview|profile|webprofile\/status)\/(\d+)/i;
  const RE_ID_PAGINA = /\/WicSales\/(\d+)/i;

  function raccogliCliente(e) {
    const m = String(e.url || '').match(RE_CLIENTE_URL);
    if (!m) return;
    const corpo = e.res || e.req;
    if (!corpo) return;
    const { email } = TGS.sale.extract([corpo], {});
    if (email) emailPerCliente[m[1]] = email;
  }

  function idClienteCorrente(payloads) {
    const daUrl = location.pathname.match(RE_ID_PAGINA);
    if (daUrl) return daUrl[1];
    let trovato = null;
    const cerca = (n, prof) => {
      if (trovato || !n || typeof n !== 'object' || prof > 6) return;
      for (const [k, v] of Object.entries(n)) {
        if (/^(customerid|idcustomer|customer_id|idcliente)$/i.test(k) && (typeof v === 'number' || typeof v === 'string')) {
          trovato = String(v);
          return;
        }
        cerca(v, prof + 1);
      }
    };
    for (const p of payloads) cerca(p, 0);
    return trovato;
  }

  /* Riepilogo a schermo: i nomi dei prodotti stanno in <label class="v-label-text">
     dentro il blocco che contiene anche "Totale". Serve perché il payload della
     vendita porta identificativi, non nomi leggibili. */
  function bloccoRiepilogo() {
    const cands = TGS.dom.resolveAll({ textContains: 'vendita: salvata con successo' })
      .filter((el) => !el.closest('#' + CTA_ID));
    const titolo = cands[cands.length - 1];
    if (!titolo) return null;
    let n = titolo;
    for (let i = 0; i < 6 && n.parentElement; i++) {
      n = n.parentElement;
      if (/totale/i.test(n.textContent || '')) return n;
    }
    return null;
  }

  function prodottiDalRiepilogo() {
    const blocco = bloccoRiepilogo();
    if (!blocco) return [];
    const scarta = /^(totale|importo pagato:?|iva|sconto)$/i;
    const soloImporto = /^[€$\s\d.,%+-]+$/;   // "0,00€", "12,50", "-5%"
    // Attenzione: TGS.dom.norm abbassa il caso (serve ai confronti), qui invece
    // il nome va conservato com'è scritto: finisce sotto gli occhi dell'utente
    // e negli abbinamenti salvati.
    const pulisci = (t) => String(t || '').replace(/\s+/g, ' ').trim();
    const nomi = Array.from(blocco.querySelectorAll('label.v-label-text, label.vapor-input-label'))
      .map((el) => pulisci(el.textContent))
      .filter((t) => t && !scarta.test(t) && !soloImporto.test(t) && t.length <= 120);
    return Array.from(new Set(nomi)).map((name) => ({ name, qty: 1, price: null }));
  }

  function extractSale(payloads, meta) {
    const { email, products } = TGS.sale.extract(payloads, {
      emailPaths: config.wic.detect.emailPaths || []
    });
    let mail = email;
    let origineEmail = email ? 'payload' : null;

    // Cliente identificato per id: è la via affidabile (vedi sopra).
    if (!mail) {
      const id = idClienteCorrente(payloads);
      if (id && emailPerCliente[id]) {
        mail = emailPerCliente[id];
        origineEmail = 'scheda cliente';
      }
    }

    // Ultima spiaggia, poco affidabile: la prima email visibile nella pagina.
    // In testata c'è quella dell'operatore, quindi il pannello la segnala e
    // chiede conferma prima di sincronizzare.
    if (!mail && document.body) {
      const m = (document.body.innerText || '').match(EMAIL_RE);
      if (m) { mail = m[0]; origineEmail = 'pagina'; }
    }

    // I nomi dei prodotti spesso non sono nel payload: si leggono dal riepilogo.
    let righe = products;
    if (!righe.length) righe = prodottiDalRiepilogo();
    return {
      id: 'sale-' + Date.now(),
      at: Date.now(),
      source: meta.source,
      url: meta.url || location.href,
      pageUrl: location.href,
      email: mail || null,
      emailSource: origineEmail,
      products: righe
    };
  }

  /* ---------- riconoscimento della vendita ---------- */

  function urlMatchesSale(url, method, status) {
    const det = config.wic.detect;
    const methods = det.methods || [];
    if (methods.length && !methods.includes(method)) return false;
    if (status && (status < 200 || status >= 300)) return false;
    const u = String(url).toLowerCase();
    return (det.apiPatterns || []).some((p) => p && u.includes(String(p).toLowerCase()));
  }

  function sameSale(a, b) {
    if (!a || !b) return false;
    if (a.email !== b.email) return false;
    const ka = a.products.map((p) => p.name).join('|');
    const kb = b.products.map((p) => p.name).join('|');
    return ka === kb && Math.abs(a.at - b.at) < 60000;
  }

  /* Un prodotto è sincronizzabile se ha un abbinamento confermato oppure se è
     marcato "chiedi sempre". Sul listino WIC ci sono centinaia di voci che su
     Technogym non devono finire: senza questo filtro il pulsante comparirebbe
     ad ogni vendita, anche quando non c'è nulla da sincronizzare. */
  function haProdottoSincronizzabile(sale) {
    return (sale.products || []).some((p) =>
      TGS.storage.resolveMapping(config, p.name) || TGS.storage.isAskAlways(config, p.name));
  }

  function onSaleDetected(sale) {
    if (!sale.email && !sale.products.length) return;
    if (sameSale(sale, lastSale)) return;
    lastSale = sale;

    // La vendita viene comunque segnalata al pannello: se lo apri dall'icona
    // la trovi lì, anche quando il pulsante resta nascosto.
    inviaAlBackground({ type: MSG.SALE_DETECTED, sale });

    sale.buttonHidden = null;
    if (!config.options.autoDetectSale) {
      sale.buttonHidden = 'rilevamento automatico disattivato';
    } else if (config.options.onlyMappedProducts && !haProdottoSincronizzabile(sale)) {
      sale.buttonHidden = 'nessun prodotto abbinato o "chiedi sempre"';
    }
    if (!sale.buttonHidden) showButton(sale);
  }

  // Il portale fa molte chiamate: si scrive su storage al massimo una volta al
  // secondo, altrimenti il log di diagnostica costa più della funzione utile.
  let persistTimer = null;
  function persistNetLog() {
    if (persistTimer) return;
    persistTimer = setTimeout(() => {
      persistTimer = null;
      salvaInStorage({ [TGS.NET_LOG_KEY]: netLog });
    }, 1000);
  }

  window.addEventListener('message', (ev) => {
    if (ev.source !== window || !ev.data || ev.data.source !== 'tgs-net') return;
    const e = ev.data.payload;
    if (!config) return;
    if (contestoMorto) return;
    if (!contestoVivo()) return segnalaContestoMorto();

    raccogliCliente(e);

    if (config.options.netLogEnabled) {
      netLog.unshift({
        url: e.url, method: e.method, status: e.status, at: e.at,
        hasEmail: EMAIL_RE.test(JSON.stringify(e.res || e.req || '').slice(0, 20000)),
        preview: JSON.stringify(e.res || e.req || null).slice(0, 400)
      });
      netLog.length = Math.min(netLog.length, config.options.netLogMax || 60);
      persistNetLog();
    }

    if (urlMatchesSale(e.url, e.method, e.status)) {
      const sale = extractSale([e.res, e.req], { source: 'api', url: e.url });
      onSaleDetected(sale);   // decide se mostrare il pulsante
      traccia(e, sale);       // e la traccia ne riporta l'esito
    }
  });

  /* Traccia diagnostica leggibile da fuori (console + attributo sul <html>).
     Serve a capire, quando il pulsante non compare o compare senza prodotti,
     se il corpo della risposta è arrivato al content script e se l'estrazione
     ci ha trovato qualcosa. Solo forma dei dati: nessun contenuto personale. */
  function traccia(e, sale) {
    const info = {
      url: String(e.url || '').split('?')[0].slice(-60),
      metodo: e.method,
      stato: e.status,
      tipoRes: e.res === undefined ? 'assente' : (e.res === null ? 'null' : typeof e.res),
      chiaviRes: e.res && typeof e.res === 'object' ? Object.keys(e.res).length : 0,
      tipoReq: e.req === undefined ? 'assente' : (e.req === null ? 'null' : typeof e.req),
      emailTrovata: !!sale.email,
      origineEmail: sale.emailSource || 'nessuna',
      prodotti: sale.products.length,
      pulsante: sale.buttonHidden ? 'nascosto: ' + sale.buttonHidden : 'mostrato'
    };
    try {
      document.documentElement.dataset.tgsDiag = JSON.stringify(info);
    } catch (_) { /* pagina che blocca dataset */ }
    console.log('[Sync WIC→Technogym] chiamata vendita rilevata:', info);
  }

  /* ---------- riconoscimento dal testo a schermo (ripiego) ---------- */

  let domTimer = null;
  const domObserver = new MutationObserver((mutations) => {
    if (!config || domTimer) return;
    // Le mutazioni prodotte dal nostro stesso pulsante non contano: il suo
    // titolo ("Vendita completata") è una delle frasi che cerchiamo, e senza
    // questo filtro il rilevamento da DOM si auto-innescava e sovrascriveva
    // la vendita ricca appena letta dalla chiamata API con una vuota.
    const soloNostre = mutations.every((m) => {
      const n = m.target;
      return n && n.nodeType === 1 && n.closest && n.closest('#' + CTA_ID);
    });
    if (soloNostre) return;

    domTimer = setTimeout(() => {
      domTimer = null;
      // La rilevazione via API porta email e prodotti; quella da testo no.
      // Se ne è appena arrivata una buona, non la si degrada.
      if (lastSale && lastSale.source === 'api' && Date.now() - lastSale.at < 120000) return;

      const triggers = config.wic.detect.domTriggers || [];
      const hit = triggers.some((t) =>
        TGS.dom.resolveAll(t).some((el) => !el.closest('#' + CTA_ID))
      );
      if (hit) onSaleDetected(extractSale([], { source: 'dom' }));
    }, 700);
  });

  /* ---------- pulsante ---------- */

  /* Posizione del pulsante. Il valore predefinito (in basso a sinistra, dal
     CSS) sta lontano dalla barra dei pulsanti del riepilogo vendita, che è in
     basso a destra; se serve, si trascina dove si vuole e la posizione resta. */
  function applicaPosizione(box) {
    if (!posizioneCta) return;
    const left = Math.min(Math.max(0, posizioneCta.left), Math.max(0, innerWidth - 140));
    const top = Math.min(Math.max(0, posizioneCta.top), Math.max(0, innerHeight - 44));
    Object.assign(box.style, { left: left + 'px', top: top + 'px', right: 'auto', bottom: 'auto' });
  }

  function rendiTrascinabile(box) {
    let inizio = null;
    box.addEventListener('pointerdown', (ev) => {
      if (ev.target.closest('button')) return;   // i pulsanti restano cliccabili
      const r = box.getBoundingClientRect();
      inizio = { x: ev.clientX, y: ev.clientY, left: r.left, top: r.top };
      box.setPointerCapture(ev.pointerId);
      box.classList.add('tgs-cta--drag');
    });
    box.addEventListener('pointermove', (ev) => {
      if (!inizio) return;
      Object.assign(box.style, {
        left: (inizio.left + ev.clientX - inizio.x) + 'px',
        top: (inizio.top + ev.clientY - inizio.y) + 'px',
        right: 'auto', bottom: 'auto'
      });
    });
    const fine = () => {
      if (!inizio) return;
      inizio = null;
      box.classList.remove('tgs-cta--drag');
      const r = box.getBoundingClientRect();
      posizioneCta = { left: Math.round(r.left), top: Math.round(r.top) };
      salvaInStorage({ [POS_KEY]: posizioneCta });
    };
    box.addEventListener('pointerup', fine);
    box.addEventListener('pointercancel', fine);
  }

  function mostraAvviso(testo) {
    if (!document.body) {
      document.addEventListener('DOMContentLoaded', () => mostraAvviso(testo), { once: true });
      return;
    }
    document.getElementById(NOTICE_ID)?.remove();
    const box = document.createElement('div');
    box.id = NOTICE_ID;
    box.className = 'tgs-notice';
    box.innerHTML = '<span></span><button type="button" title="Chiudi">×</button>';
    box.querySelector('span').textContent = testo;
    box.querySelector('button').addEventListener('click', () => box.remove());
    document.body.appendChild(box);
  }

  function showButton(sale) {
    // A document_start il body può non esistere ancora: si attende.
    if (!document.body) {
      document.addEventListener('DOMContentLoaded', () => showButton(sale), { once: true });
      return;
    }
    document.getElementById(CTA_ID)?.remove();
    const box = document.createElement('div');
    box.id = CTA_ID;
    box.innerHTML = `
      <div class="tgs-cta__body">
        <div class="tgs-cta__title">Vendita completata</div>
        <div class="tgs-cta__sub"></div>
      </div>
      <button class="tgs-cta__btn" type="button">Sincronizza su Technogym</button>
      <button class="tgs-cta__close" type="button" title="Chiudi">×</button>`;
    box.querySelector('.tgs-cta__sub').textContent =
      (sale.email || 'email non rilevata') +
      (sale.products.length ? ' · ' + sale.products.map((p) => p.name).join(', ') : '');
    box.querySelector('.tgs-cta__btn').addEventListener('click', () => {
      if (inviaAlBackground({ type: MSG.OPEN_PANEL, sale })) {
        box.classList.add('tgs-cta--sent');
      }
    });
    box.querySelector('.tgs-cta__close').addEventListener('click', () => box.remove());
    box.title = 'Trascina per spostare';
    applicaPosizione(box);
    rendiTrascinabile(box);
    document.body.appendChild(box);
  }

  /* ---------- messaggi dal pannello / opzioni ---------- */

  chrome.runtime.onMessage.addListener((msg, _s, sendResponse) => {
    if (msg.type === 'wic-get-last-sale') {
      sendResponse({ sale: lastSale });
      return true;
    }
    if (msg.type === 'wic-rescan') {
      if (!config) { sendResponse({ error: 'configurazione non ancora caricata' }); return true; }
      const sale = extractSale([], { source: 'dom' });
      lastSale = sale;
      sendResponse({ sale });
      return true;
    }
    return false;
  });

  /* ---------- avvio ---------- */

  chrome.storage.local.get(POS_KEY).then((r) => { posizioneCta = r[POS_KEY] || null; }).catch(() => {});

  TGS.storage.getConfig().then((cfg) => {
    config = cfg;
    domObserver.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  });
  // Le modifiche possono arrivare dal computer stesso (area 'local') o da un
  // altro computer con lo stesso account (area 'sync'): in entrambi i casi si
  // rilegge la configurazione completa, che le fonde.
  chrome.storage.onChanged.addListener(() => {
    if (contestoMorto) return;
    TGS.storage.getConfig().then((cfg) => { config = cfg; }, () => {});
  });
})();
