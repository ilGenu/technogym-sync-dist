/* Pannello laterale: mostra la vendita rilevata, l'abbinamento dei prodotti e
   l'avanzamento della sincronizzazione. */
(function () {
  const { MSG, JOB_STATUS } = TGS;
  const $ = (id) => document.getElementById(id);

  let config = null;
  let sale = null;
  let job = null;
  const overrides = {};   // nome WIC -> nome MyWellness scelto a mano

  const send = (msg) => chrome.runtime.sendMessage(msg).catch(() => null);

  /* ---------- interfaccia ---------- */

  function renderSale() {
    const empty = !sale || (!sale.email && !(sale.products || []).length);
    $('sale-empty').classList.toggle('hidden', !empty);
    $('email').value = (sale && sale.email) || '';

    // Un'email letta dalla pagina invece che dai dati della vendita può essere
    // di un'altra persona (o dell'operatore): va guardata prima di procedere.
    document.getElementById('email-hint')?.remove();
    if (sale && sale.emailSource === 'pagina') {
      const hint = document.createElement('div');
      hint.id = 'email-hint';
      hint.className = 'muted';
      hint.style.margin = '-8px 0 12px';
      hint.textContent = 'Email letta dalla pagina, non dai dati della vendita: controllala.';
      $('email').parentElement.after(hint);
    }

    const host = $('products');
    host.innerHTML = '';
    const products = (sale && sale.products) || [];

    if (!products.length) {
      host.appendChild(manualProductRow());
      return;
    }
    products.forEach((p) => host.appendChild(productRow(p.name, p.qty)));
  }

  function mwCatalog() {
    return (config && config.catalogs && config.catalogs.mw) || [];
  }

  function productRow(wicName, qty) {
    const row = document.createElement('div');
    row.className = 'product';

    const title = document.createElement('div');
    title.className = 'product__name';
    title.textContent = wicName + (qty && qty !== 1 ? ` ×${qty}` : '');
    row.appendChild(title);

    const map = TGS.storage.resolveMapping(config, wicName);
    const line = document.createElement('div');
    line.className = 'product__map';

    if (map) {
      overrides[wicName] = map.mwName;
      line.innerHTML = '<span class="badge badge--ok">abbinato</span>';
      const t = document.createElement('span');
      t.textContent = '→ ' + map.mwName;
      line.appendChild(t);
    } else {
      line.innerHTML = '<span class="badge badge--warn">da abbinare</span>';
      const suggestions = TGS.fuzzy.rank(wicName, mwCatalog(), { limit: 6, threshold: 0.2 });
      const sel = document.createElement('select');
      sel.innerHTML = '<option value="">— scegli il prodotto MyWellness —</option>';
      const listed = new Set();
      suggestions.forEach((s) => {
        listed.add(s.name);
        const o = document.createElement('option');
        o.value = s.name;
        o.textContent = `${s.name} · ${Math.round(s.score * 100)}%`;
        sel.appendChild(o);
      });
      mwCatalog().forEach((n) => {
        const name = typeof n === 'string' ? n : n.name;
        if (listed.has(name)) return;
        const o = document.createElement('option');
        o.value = name;
        o.textContent = name;
        sel.appendChild(o);
      });
      if (suggestions.length && suggestions[0].score >= 0.62) sel.value = suggestions[0].name;
      overrides[wicName] = sel.value || '';
      sel.addEventListener('change', () => {
        overrides[wicName] = sel.value;
        updateStartState();
      });
      row.appendChild(line);
      row.appendChild(sel);

      if (!mwCatalog().length) {
        const hint = document.createElement('div');
        hint.className = 'muted';
        hint.style.marginTop = '6px';
        hint.textContent = 'Listino MyWellness non ancora letto: fallo dalle Impostazioni.';
        row.appendChild(hint);
      }

      const chiedeSempre = TGS.storage.isAskAlways(config, wicName);
      if (chiedeSempre) {
        const nota = document.createElement('div');
        nota.className = 'muted';
        nota.style.marginTop = '6px';
        nota.textContent = 'Questo prodotto ha più varianti su MyWellness: la scelta va fatta ogni volta.';
        row.appendChild(nota);
      }

      // Su una postazione governata da policy gli abbinamenti non si salvano:
      // offrire la spunta darebbe l'illusione di poterlo fare.
      if (config.gestita && config.soloLettura) return row;

      const remember = document.createElement('label');
      remember.className = 'check';
      remember.style.marginTop = '6px';
      remember.innerHTML = '<input type="checkbox"> ricorda questo abbinamento';
      // Preselezionata solo quando ha senso ricordare: per un prodotto che
      // chiede sempre la variante, ricordare sarebbe l'errore da evitare.
      remember.querySelector('input').checked = !chiedeSempre;
      remember.querySelector('input').dataset.remember = wicName;
      row.appendChild(remember);
      return row;
    }

    row.appendChild(line);
    return row;
  }

  function manualProductRow() {
    const row = document.createElement('div');
    row.className = 'product';
    row.innerHTML = '<div class="product__name">Prodotto da registrare</div>';
    const sel = document.createElement('select');
    sel.id = 'manual-product';
    sel.innerHTML = '<option value="">— scegli il prodotto MyWellness —</option>';
    mwCatalog().forEach((n) => {
      const name = typeof n === 'string' ? n : n.name;
      const o = document.createElement('option');
      o.value = name;
      o.textContent = name;
      sel.appendChild(o);
    });
    sel.addEventListener('change', updateStartState);
    row.appendChild(sel);
    return row;
  }

  function stepIcon(status) {
    return { pending: '·', running: '◐', waiting: '⏸', done: '✓', failed: '✕', skipped: '–' }[status] || '·';
  }

  function renderJob() {
    const box = $('progress');
    if (!job) { box.classList.add('hidden'); return; }
    box.classList.remove('hidden');

    const list = $('steps');
    list.innerHTML = '';
    job.steps.forEach((s) => {
      const li = document.createElement('li');
      li.className = 'st-' + s.status;
      const ico = document.createElement('span');
      ico.className = 'ico';
      ico.textContent = stepIcon(s.status);
      const body = document.createElement('span');
      body.textContent = s.label;
      if (s.detail) {
        const d = document.createElement('small');
        d.className = 'detail';
        d.textContent = s.detail;
        body.appendChild(d);
      }
      li.append(ico, body);
      list.appendChild(li);
    });

    const failed = job.status === JOB_STATUS.FAILED || job.status === JOB_STATUS.CANCELLED;
    if (failed) {
      $('job-error').classList.remove('hidden');
      $('job-error').textContent = job.error || '';
    }
    $('job-done').classList.toggle('hidden', job.status !== JOB_STATUS.DONE);
    $('focus-tab').classList.toggle('hidden', job.workTabId == null);
    $('cancel').classList.toggle('hidden', job.status !== JOB_STATUS.RUNNING && job.status !== JOB_STATUS.NEEDS_LOGIN);
    updateStartState();
  }

  function updateStartState() {
    const running = job && (job.status === JOB_STATUS.RUNNING || job.status === JOB_STATUS.NEEDS_LOGIN);
    const email = $('email').value.trim();
    const chosen = Object.values(overrides).filter(Boolean).length ||
      ($('manual-product') && $('manual-product').value);
    $('start').disabled = !!running || !email || !chosen;
    $('start').textContent = running ? 'Sincronizzazione in corso…' : 'Sincronizza su Technogym';
  }

  /* ---------- azioni ---------- */

  async function rememberMappings() {
    if (config.gestita && config.soloLettura) return;
    const boxes = document.querySelectorAll('input[data-remember]');
    if (!boxes.length) return;
    const cfg = await TGS.storage.getConfig();
    let changed = false;
    boxes.forEach((b) => {
      const wicName = b.dataset.remember;
      const mwName = overrides[wicName];
      if (!b.checked || !mwName) return;
      const existing = cfg.mappings.find(
        (m) => TGS.fuzzy.normalize(m.wicName) === TGS.fuzzy.normalize(wicName)
      );
      if (existing) Object.assign(existing, { mwName, confirmed: true, updatedAt: Date.now() });
      else cfg.mappings.push({ wicName, mwName, confirmed: true, score: 1, updatedAt: Date.now() });
      changed = true;
    });
    if (changed) {
      await TGS.storage.setConfig(cfg);
      config = cfg;
    }
  }

  async function start() {
    await rememberMappings();

    const email = $('email').value.trim();
    let products = (sale && sale.products) || [];
    if (!products.length) {
      const manual = $('manual-product') && $('manual-product').value;
      if (!manual) return;
      products = [{ name: manual, qty: 1, price: null }];
      overrides[manual] = manual;
    }

    const payload = {
      type: MSG.START_SYNC,
      sale: Object.assign({}, sale || {}, { email, products }),
      overrides
    };
    const res = await send(payload);
    if (res && !res.ok) {
      job = { status: JOB_STATUS.FAILED, steps: [], error: res.error, workTabId: null };
      renderJob();
      return;
    }
    // Il lavoro parte anche se solo una parte dei prodotti è abbinata: dirlo,
    // altrimenti sembra sincronizzato tutto.
    if (res && res.unmapped && res.unmapped.length) {
      $('progress').classList.remove('hidden');
      const warn = $('job-error');
      warn.classList.remove('hidden');
      warn.textContent = 'Non sincronizzati (nessun abbinamento): ' + res.unmapped.join(', ');
    }
  }

  /* ---------- avvio ---------- */

  async function refresh() {
    const state = await send({ type: MSG.GET_STATE });
    if (!state || !state.ok) return;
    config = TGS.storage.withDefaults(state.config);
    sale = state.sale;
    job = state.job;
    $('dry').checked = !!config.options.dryRun;
    renderSale();
    renderJob();
    updateStartState();
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === MSG.JOB_UPDATE) { job = msg.job; renderJob(); }
    if (msg.type === MSG.SALE_DETECTED) { sale = msg.sale; renderSale(); updateStartState(); }
  });

  $('start').addEventListener('click', start);
  $('cancel').addEventListener('click', () => send({ type: MSG.CANCEL_SYNC }));
  $('focus-tab').addEventListener('click', () => send({ type: MSG.FOCUS_WORK_TAB }));
  $('email').addEventListener('input', updateStartState);
  $('open-options').addEventListener('click', () => chrome.runtime.openOptionsPage());
  $('dry').addEventListener('change', async () => {
    const cfg = await TGS.storage.getConfig();
    cfg.options.dryRun = $('dry').checked;
    await TGS.storage.setConfig(cfg);
    config = cfg;
  });

  refresh();
})();
