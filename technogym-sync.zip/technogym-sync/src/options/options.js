/* Pagina delle impostazioni: listini, abbinamenti, rilevamento vendita,
   ricetta MyWellness, opzioni e import/export della configurazione. */
(function () {
  const { MSG } = TGS;
  const $ = (id) => document.getElementById(id);
  const send = (msg) => chrome.runtime.sendMessage(msg).catch((e) => ({ ok: false, error: String(e) }));

  let cfg = null;
  let pendingPick = null;   // { kind: 'step'|'catalog'|'loggedOut', index?, site }

  const names = (list) => (list || []).map((x) => (typeof x === 'string' ? x : x && x.name)).filter(Boolean);
  const lines = (txt) => txt.split('\n').map((s) => s.trim()).filter(Boolean);

  function toast(text) {
    const t = $('toast');
    t.textContent = text;
    t.classList.remove('hidden');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => t.classList.add('hidden'), 2600);
  }

  /* ---------- listini ---------- */

  function renderCatalogs() {
    for (const site of ['wic', 'mw']) {
      const host = $('catalog-' + site);
      const list = names(cfg.catalogs[site]);
      const meta = (site === 'wic' ? cfg.wic : cfg.mywellness).catalog || {};
      host.innerHTML = '';
      if (!list.length) {
        host.innerHTML = '<div class="muted">nessun prodotto letto</div>';
      } else {
        const head = document.createElement('div');
        head.className = 'muted';
        head.textContent = `${list.length} prodotti` +
          (meta.capturedAt ? ' · letti il ' + new Date(meta.capturedAt).toLocaleString('it-IT') : '');
        host.appendChild(head);
        list.forEach((n) => {
          const d = document.createElement('div');
          d.textContent = n;
          host.appendChild(d);
        });
      }
      const area = document.querySelector(`[data-paste-area="${site}"]`);
      if (area && !area.value) area.value = list.join('\n');
    }
  }

  /* ---------- abbinamenti ---------- */

  function rowsForMaps() {
    const wicNames = names(cfg.catalogs.wic);
    const rows = [];
    const seen = new Set();
    wicNames.forEach((n) => {
      const key = TGS.fuzzy.normalize(n);
      seen.add(key);
      const m = cfg.mappings.find((x) => TGS.fuzzy.normalize(x.wicName) === key);
      rows.push(m || { wicName: n, mwName: '', confirmed: false, score: 0 });
    });
    // Abbinamenti salvati per prodotti non più presenti nel listino letto.
    cfg.mappings.forEach((m) => {
      if (!seen.has(TGS.fuzzy.normalize(m.wicName))) rows.push(m);
    });
    return rows;
  }

  function upsertMapping(wicName, patch) {
    const key = TGS.fuzzy.normalize(wicName);
    let m = cfg.mappings.find((x) => TGS.fuzzy.normalize(x.wicName) === key);
    if (!m) {
      m = { wicName, mwName: '', confirmed: false, score: 0 };
      cfg.mappings.push(m);
    }
    Object.assign(m, patch, { updatedAt: Date.now() });
    return m;
  }

  function renderMaps() {
    const body = $('maps-body');
    const mwNames = names(cfg.catalogs.mw);
    const rows = rowsForMaps();
    body.innerHTML = '';

    rows.forEach((row) => {
      const tr = document.createElement('tr');

      const tdA = document.createElement('td');
      tdA.textContent = row.wicName;
      tr.appendChild(tdA);

      const tdB = document.createElement('td');
      const sel = document.createElement('select');
      sel.innerHTML = '<option value="">— nessuno —</option>';
      mwNames.forEach((n) => {
        const o = document.createElement('option');
        o.value = n;
        o.textContent = n;
        sel.appendChild(o);
      });
      if (row.mwName && !mwNames.includes(row.mwName)) {
        const o = document.createElement('option');
        o.value = row.mwName;
        o.textContent = row.mwName + ' (non nel listino letto)';
        sel.appendChild(o);
      }
      sel.value = row.mwName || '';
      sel.addEventListener('change', () => {
        const score = sel.value ? TGS.fuzzy.similarity(row.wicName, sel.value) : 0;
        upsertMapping(row.wicName, { mwName: sel.value, score, confirmed: false });
        renderMaps();
      });
      tdB.appendChild(sel);
      tr.appendChild(tdB);

      const tdC = document.createElement('td');
      if (row.mwName) {
        const score = row.score || TGS.fuzzy.similarity(row.wicName, row.mwName);
        const lvl = TGS.fuzzy.confidence(score);
        tdC.innerHTML = `<span class="badge badge--${lvl}">${Math.round(score * 100)}% ${lvl}</span>`;
      }
      tr.appendChild(tdC);

      const tdD = document.createElement('td');
      const chk = document.createElement('input');
      chk.type = 'checkbox';
      chk.checked = !!row.confirmed;
      chk.disabled = !row.mwName;
      chk.addEventListener('change', () => {
        upsertMapping(row.wicName, { mwName: row.mwName, confirmed: chk.checked });
        updateMapSummary();
      });
      tdD.appendChild(chk);
      tr.appendChild(tdD);

      /* "Chiedi sempre": per i prodotti WIC generici che su MyWellness hanno
         più varianti. L'abbinamento non viene mai risolto in automatico, il
         pannello chiede quale usare ad ogni vendita. */
      const tdAsk = document.createElement('td');
      const ask = document.createElement('input');
      ask.type = 'checkbox';
      ask.checked = !!row.askAlways;
      ask.title = 'Il pannello chiederà quale variante usare ad ogni vendita';
      ask.addEventListener('change', () => {
        upsertMapping(row.wicName, { mwName: row.mwName, confirmed: row.confirmed, askAlways: ask.checked });
        renderMaps();
      });
      tdAsk.appendChild(ask);
      tr.appendChild(tdAsk);

      const tdE = document.createElement('td');
      const del = document.createElement('button');
      del.className = 'link';
      del.textContent = 'rimuovi';
      del.addEventListener('click', () => {
        cfg.mappings = cfg.mappings.filter(
          (x) => TGS.fuzzy.normalize(x.wicName) !== TGS.fuzzy.normalize(row.wicName)
        );
        renderMaps();
      });
      tdE.appendChild(del);
      tr.appendChild(tdE);

      body.appendChild(tr);
    });

    updateMapSummary();
  }

  function updateMapSummary() {
    const confirmed = cfg.mappings.filter((m) => m.confirmed && m.mwName && !m.askAlways).length;
    const chiedono = cfg.mappings.filter((m) => m.askAlways).length;
    const total = rowsForMaps().length;
    $('map-summary').textContent = total
      ? `${confirmed} confermati su ${total}` + (chiedono ? ` · ${chiedono} chiedono sempre la variante` : '')
      : 'leggi prima i due listini';
  }

  function propose() {
    const mwNames = names(cfg.catalogs.mw);
    if (!mwNames.length) return toast('Prima leggi il listino MyWellness');
    let n = 0;
    names(cfg.catalogs.wic).forEach((wicName) => {
      const key = TGS.fuzzy.normalize(wicName);
      const existing = cfg.mappings.find((x) => TGS.fuzzy.normalize(x.wicName) === key);
      if (existing && existing.confirmed) return;   // non tocca ciò che hai confermato
      const best = TGS.fuzzy.best(wicName, mwNames, 0.35);
      if (!best) return;
      upsertMapping(wicName, { mwName: best.name, score: best.score, confirmed: false });
      n++;
    });
    renderMaps();
    toast(n ? `${n} abbinamenti proposti — vanno confermati` : 'nessuna nuova proposta');
  }

  /* ---------- rilevamento vendita ---------- */

  function renderDetect() {
    const d = cfg.wic.detect;
    $('api-patterns').value = (d.apiPatterns || []).join('\n');
    $('dom-triggers').value = (d.domTriggers || [])
      .map((t) => t.textContains || t.text || '')
      .filter(Boolean).join('\n');
    $('email-paths').value = (d.emailPaths || []).join('\n');
  }

  async function renderNetLog() {
    const raw = await chrome.storage.local.get(TGS.NET_LOG_KEY);
    const log = raw[TGS.NET_LOG_KEY] || [];
    const body = $('netlog-body');
    body.innerHTML = '';
    if (!log.length) {
      body.innerHTML = '<tr><td colspan="5" class="muted">nessuna chiamata registrata</td></tr>';
      return;
    }
    log.forEach((e) => {
      const tr = document.createElement('tr');
      const path = (() => { try { return new URL(e.url, 'https://x').pathname; } catch (_) { return e.url; } })();
      tr.innerHTML =
        `<td>${new Date(e.at).toLocaleTimeString('it-IT')}</td>` +
        `<td>${e.method} ${e.status || ''}</td>` +
        `<td class="url" title="${(e.preview || '').replace(/"/g, '&quot;')}">${path}</td>` +
        `<td>${e.hasEmail ? '✓' : ''}</td>`;
      const td = document.createElement('td');
      const b = document.createElement('button');
      b.className = 'link';
      b.textContent = 'usa come pattern';
      b.addEventListener('click', () => {
        const frag = path.split('/').filter(Boolean).pop() || path;
        const cur = lines($('api-patterns').value);
        if (!cur.includes(frag)) cur.push(frag);
        $('api-patterns').value = cur.join('\n');
        toast('aggiunto: ' + frag + ' — ricordati di salvare');
      });
      td.appendChild(b);
      tr.appendChild(td);
      body.appendChild(tr);
    });
  }

  /* ---------- ricetta ---------- */

  const ACTIONS = ['navigate', 'requireLogin', 'click', 'fill', 'pressKey', 'pickFromList',
    'waitFor', 'waitGone', 'assertText', 'extractText', 'sleep'];

  function renderRecipe() {
    const host = $('steps');
    host.innerHTML = '';
    cfg.mywellness.recipe.forEach((step, i) => {
      const card = document.createElement('div');
      card.className = 'step';

      const head = document.createElement('div');
      head.className = 'step__head';
      const label = document.createElement('input');
      label.type = 'text';
      label.value = step.label || '';
      label.placeholder = 'etichetta mostrata nel pannello';
      label.addEventListener('input', () => { step.label = label.value; ricettaModificata(); });

      const tools = document.createElement('div');
      tools.className = 'step__tools';
      const mk = (txt, title, fn) => {
        const b = document.createElement('button');
        b.type = 'button';
        b.textContent = txt;
        b.title = title;
        b.addEventListener('click', fn);
        return b;
      };
      tools.append(
        mk('Cattura', 'cattura il selettore da MyWellness', () => {
          pendingPick = { kind: 'step', index: i, site: 'mw' };
          send({ type: MSG.START_PICKER, site: 'mw', mode: 'selector' }).then((r) => {
            toast(r && r.ok ? 'Clicca l\'elemento sulla scheda MyWellness' : (r && r.error) || 'errore');
            if (!r || !r.ok) pendingPick = null;
          });
        }),
        mk('↑', 'sposta su', () => { if (i > 0) { swap(i, i - 1); } }),
        mk('↓', 'sposta giù', () => { if (i < cfg.mywellness.recipe.length - 1) swap(i, i + 1); }),
        mk('×', 'elimina', () => { cfg.mywellness.recipe.splice(i, 1); ricettaModificata(); renderRecipe(); })
      );
      head.append(label, tools);

      const grid = document.createElement('div');
      grid.className = 'step__grid';

      const act = document.createElement('select');
      ACTIONS.forEach((a) => {
        const o = document.createElement('option');
        o.value = a; o.textContent = a;
        act.appendChild(o);
      });
      act.value = step.action;
      act.addEventListener('change', () => { step.action = act.value; ricettaModificata(); });

      const val = document.createElement('input');
      val.type = 'text';
      val.placeholder = 'valore — {{email}}, {{mwProduct}}, Enter, ms…';
      val.value = step.value == null ? '' : step.value;
      val.addEventListener('input', () => { step.value = val.value; ricettaModificata(); });

      const target = document.createElement('textarea');
      target.rows = 3;
      target.value = step.target ? JSON.stringify(step.target, null, 0) : '';
      target.placeholder = 'target JSON, es. {"css":".btn-add"} oppure {"textContains":"acquisti"}';
      target.dataset.stepTarget = String(i);
      target.addEventListener('change', () => {
        const t = target.value.trim();
        if (!t) { delete step.target; return; }
        try { step.target = JSON.parse(t); target.style.borderColor = ''; ricettaModificata(); }
        catch (_) { target.style.borderColor = 'var(--err)'; toast('JSON non valido nel passo ' + (i + 1)); }
      });

      const flags = document.createElement('label');
      flags.className = 'check';
      flags.innerHTML = '<input type="checkbox"> opzionale (se non trovato prosegue)';
      const fchk = flags.querySelector('input');
      fchk.checked = !!step.optional;
      fchk.addEventListener('change', () => { step.optional = fchk.checked; ricettaModificata(); });

      const confirmFlag = document.createElement('label');
      confirmFlag.className = 'check';
      confirmFlag.innerHTML = '<input type="checkbox"> è la conferma finale (saltata in modalità prova)';
      const cchk = confirmFlag.querySelector('input');
      cchk.checked = !!step.confirmStep;
      cchk.addEventListener('change', () => { step.confirmStep = cchk.checked; ricettaModificata(); });

      grid.append(act, val, target, flags, confirmFlag);
      card.append(head, grid);
      host.appendChild(card);
    });

    $('logged-out').value = JSON.stringify(cfg.mywellness.loggedOut || {}, null, 0);
    $('start-url').value = cfg.mywellness.startUrl || '';
  }

  /* Segna la ricetta come modificata a mano: da qui in poi gli aggiornamenti
     dei valori predefiniti non la sovrascrivono più. */
  function ricettaModificata() {
    cfg.mywellness.recipeEdited = true;
  }

  function swap(a, b) {
    ricettaModificata();
    const r = cfg.mywellness.recipe;
    [r[a], r[b]] = [r[b], r[a]];
    renderRecipe();
  }

  /* ---------- opzioni ---------- */

  function renderOptions() {
    const o = cfg.options;
    $('opt-showtab').checked = !!o.showWorkTab;
    $('opt-dry').checked = !!o.dryRun;
    $('opt-reusetab').checked = o.reuseTab !== false;
    $('opt-autodetect').checked = !!o.autoDetectSale;
    $('opt-onlymapped').checked = o.onlyMappedProducts !== false;
    $('opt-netlog').checked = !!o.netLogEnabled;
    $('opt-timeout').value = Math.round((o.stepTimeoutMs || 20000) / 1000);
    $('opt-panel').value = o.panelMode || 'sidepanel';
    $('opt-sync').checked = o.syncEnabled !== false;
    mostraStatoSync();
  }

  /* ---------- salvataggio ---------- */

  function collect() {
    cfg.wic.detect.apiPatterns = lines($('api-patterns').value);
    cfg.wic.detect.domTriggers = lines($('dom-triggers').value).map((t) => ({ textContains: t }));
    cfg.wic.detect.emailPaths = lines($('email-paths').value);

    // "modificato" solo se davvero diverso dai predefiniti: premere Salva senza
    // cambiare nulla non deve congelare la sezione agli aggiornamenti futuri.
    const d = TGS.DEFAULT_CONFIG.wic.detect;
    const uguale = (a, b) => JSON.stringify(a) === JSON.stringify(b);
    cfg.wic.detect.edited = !uguale(cfg.wic.detect.apiPatterns, d.apiPatterns) ||
      !uguale(cfg.wic.detect.domTriggers, d.domTriggers) ||
      !uguale(cfg.wic.detect.emailPaths, d.emailPaths);

    try { cfg.mywellness.loggedOut = JSON.parse($('logged-out').value || '{}'); }
    catch (_) { toast('JSON non valido nel riconoscimento del login'); }
    cfg.mywellness.startUrl = $('start-url').value.trim();

    cfg.options.showWorkTab = $('opt-showtab').checked;
    cfg.options.dryRun = $('opt-dry').checked;
    cfg.options.reuseTab = $('opt-reusetab').checked;
    cfg.options.autoDetectSale = $('opt-autodetect').checked;
    cfg.options.onlyMappedProducts = $('opt-onlymapped').checked;
    cfg.options.netLogEnabled = $('opt-netlog').checked;
    cfg.options.stepTimeoutMs = Math.max(3, Number($('opt-timeout').value) || 20) * 1000;
    cfg.options.panelMode = $('opt-panel').value;
    cfg.options.syncEnabled = $('opt-sync').checked;
  }

  async function save() {
    collect();
    await TGS.storage.setConfig(cfg);
    toast('Configurazione salvata');
  }

  /* ---------- import / export ---------- */

  function exportConfig() {
    collect();
    const data = JSON.stringify(cfg, null, 2);
    const url = URL.createObjectURL(new Blob([data], { type: 'application/json' }));
    const a = document.createElement('a');
    const stamp = new Date().toISOString().slice(0, 10);
    a.href = url;
    a.download = `sync-wic-technogym-${stamp}.json`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  }

  async function importConfig(file) {
    const text = await file.text();
    let parsed;
    try { parsed = JSON.parse(text); }
    catch (_) { return toast('File non valido: non è JSON'); }
    if (!parsed || typeof parsed !== 'object' || !parsed.mywellness) {
      return toast('File non riconosciuto come configurazione di questa estensione');
    }
    cfg = TGS.storage.withDefaults(parsed);
    await TGS.storage.setConfig(cfg);
    renderAll();
    toast('Configurazione importata');
  }

  /* ---------- catturatore ---------- */

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type !== MSG.PICKER_RESULT || !pendingPick) return;
    const p = msg.payload || {};
    const pick = pendingPick;
    pendingPick = null;
    if (p.cancelled) return toast('cattura annullata');

    if (pick.kind === 'catalog') {
      const site = pick.site;
      cfg.catalogs[site] = p.names || [];
      const meta = { url: p.url, itemCss: p.itemCss, nameCss: p.sampleCss, capturedAt: Date.now() };
      if (site === 'wic') cfg.wic.catalog = meta; else cfg.mywellness.catalog = meta;
      renderCatalogs();
      renderMaps();
      // Salvato subito: leggere un listino è un'azione deliberata, e restare
      // solo in memoria significherebbe perderlo chiudendo la pagina.
      TGS.storage.setConfig(cfg).then(
        () => toast(`${(p.names || []).length} prodotti letti e salvati`),
        () => toast(`${(p.names || []).length} prodotti letti — premi Salva`)
      );
      return;
    }

    if (pick.kind === 'step') {
      const step = cfg.mywellness.recipe[pick.index];
      if (!step) return;
      const t = {};
      if (p.target.css) t.css = p.target.css;
      step.target = t;
      ricettaModificata();
      renderRecipe();
      const area = document.querySelector(`[data-step-target="${pick.index}"]`);
      if (area) area.style.borderColor = 'var(--ok)';
      toast('Selettore catturato: ' + (t.css || '') + ' — ricordati di salvare');
    }

    if (pick.kind === 'loggedOut') {
      cfg.mywellness.loggedOut = { css: p.target.css };
      $('logged-out').value = JSON.stringify(cfg.mywellness.loggedOut);
      toast('Selettore del login catturato');
    }
  });

  /* ---------- avvio ---------- */

  /* Postazione governata da policy: si mostra l'avviso e si blocca tutto
     tranne la lettura dei listini, che è un aiuto locale e non cambia il
     comportamento della sincronizzazione. */
  function applicaSolaLettura() {
    const bloccata = !!(cfg.gestita && cfg.soloLettura);
    document.body.classList.toggle('sola-lettura', bloccata);
    $('banner-gestita').classList.toggle('hidden', !bloccata);

    // Il pulsante di rilettura resta attivo anche qui: scarica soltanto.
    const remota = $('aggiorna-remota');
    const stato = $('stato-remota');
    if (cfg.configurazioneUrl) {
      stato.textContent = cfg.remotaAggiornataIl
        ? 'Ultimo aggiornamento: ' + new Date(cfg.remotaAggiornataIl).toLocaleString('it-IT') + '.'
        : 'Non ancora scaricata.';
      remota.classList.remove('hidden');
    } else {
      stato.textContent = '';
      remota.classList.add('hidden');
    }
    if (bloccata) {
      // I due riquadri dei listini restano usabili.
      document.querySelectorAll('#pane-catalogs .card').forEach((c, i) => {
        if (i < 2) c.classList.add('modificabile');
      });
    }
  }

  function renderAll() {
    renderCatalogs();
    renderMaps();
    renderDetect();
    renderRecipe();
    renderOptions();
    renderNetLog();
    applicaSolaLettura();
  }

  function mostraStatoSync() {
    const el = $('sync-state');
    if (!el) return;
    if (cfg.options.syncEnabled === false) { el.textContent = 'disattivata su questo computer'; return; }
    el.textContent = cfg.syncedAt
      ? 'ultimo allineamento: ' + new Date(cfg.syncedAt).toLocaleString('it-IT')
      : 'mai sincronizzato';
  }

  function bind() {
    document.querySelectorAll('.tab').forEach((t) => {
      t.addEventListener('click', () => {
        document.querySelectorAll('.tab').forEach((x) => x.classList.toggle('is-active', x === t));
        document.querySelectorAll('.pane').forEach((p) => {
          p.classList.toggle('is-active', p.id === 'pane-' + t.dataset.tab);
        });
      });
    });

    document.querySelectorAll('[data-capture]').forEach((b) => {
      b.addEventListener('click', () => {
        const site = b.dataset.capture;
        pendingPick = { kind: 'catalog', site };
        send({ type: MSG.SCRAPE_LIST, site }).then((r) => {
          toast(r && r.ok
            ? 'Clicca il nome di un prodotto nella pagina aperta'
            : (r && r.error) || 'errore');
          if (!r || !r.ok) pendingPick = null;
        });
      });
    });

    document.querySelectorAll('[data-paste]').forEach((b) => {
      b.addEventListener('click', () => {
        const site = b.dataset.paste;
        const area = document.querySelector(`[data-paste-area="${site}"]`);
        area.classList.toggle('hidden');
        if (!area.classList.contains('hidden')) area.focus();
      });
    });
    document.querySelectorAll('[data-paste-area]').forEach((area) => {
      area.addEventListener('change', () => {
        const site = area.dataset.pasteArea;
        cfg.catalogs[site] = lines(area.value);
        renderCatalogs();
        renderMaps();
        toast(`${cfg.catalogs[site].length} prodotti — ricordati di salvare`);
      });
    });

    $('propose').addEventListener('click', propose);
    $('confirm-high').addEventListener('click', () => {
      let n = 0;
      cfg.mappings.forEach((m) => {
        const score = m.score || TGS.fuzzy.similarity(m.wicName, m.mwName);
        if (m.mwName && !m.confirmed && score >= 0.85) { m.confirmed = true; n++; }
      });
      renderMaps();
      toast(n ? `${n} abbinamenti confermati` : 'nessuno ad alta confidenza');
    });

    $('save').addEventListener('click', save);
    $('aggiorna-remota').addEventListener('click', async () => {
      const r = await send({ type: MSG.REFRESH_REMOTE });
      if (r && r.ok) {
        cfg = await TGS.storage.getConfig();
        renderAll();
        toast('Configurazione aggiornata · ' + r.abbinamenti + ' abbinamenti');
      } else {
        toast('Non aggiornata: ' + ((r && r.motivo) || 'errore'));
      }
    });

    $('sync-now').addEventListener('click', async () => {
      collect();
      await TGS.storage.setConfig(cfg);        // scrive e fonde con il cloud
      cfg = await TGS.storage.getConfig();     // rilegge l'esito della fusione
      renderAll();
      toast('Sincronizzato · ' + cfg.mappings.length + ' abbinamenti');
    });

    // Modifiche in arrivo da un altro computer: si avvisa, senza sovrascrivere
    // quello che si sta eventualmente modificando qui.
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'sync') toast('Configurazione aggiornata da un altro computer — premi "Sincronizza adesso" per vederla');
    });
    $('export').addEventListener('click', exportConfig);
    $('export2').addEventListener('click', exportConfig);
    $('import').addEventListener('change', (e) => {
      if (e.target.files[0]) importConfig(e.target.files[0]);
      e.target.value = '';
    });
    $('reload-log').addEventListener('click', renderNetLog);
    $('clear-log').addEventListener('click', async () => {
      await chrome.storage.local.remove(TGS.NET_LOG_KEY);
      renderNetLog();
    });
    $('add-step').addEventListener('click', () => {
      cfg.mywellness.recipe.push({ id: 'step-' + Date.now(), label: 'Nuovo passo', action: 'click', target: {} });
      ricettaModificata();
      renderRecipe();
    });
    $('reset-recipe').addEventListener('click', () => {
      cfg.mywellness.recipe = TGS.storage.clone(TGS.DEFAULT_CONFIG.mywellness.recipe);
      cfg.mywellness.recipeVersion = TGS.DEFAULT_CONFIG.mywellness.recipeVersion;
      delete cfg.mywellness.recipeEdited;
      renderRecipe();
      toast('ricetta ripristinata — ricordati di salvare');
    });
    $('reset-all').addEventListener('click', async () => {
      if (!confirm('Ripristinare tutta la configurazione, listini e abbinamenti compresi?')) return;
      cfg = TGS.storage.clone(TGS.DEFAULT_CONFIG);
      await TGS.storage.setConfig(cfg);
      renderAll();
      toast('configurazione ripristinata');
    });
  }

  TGS.storage.getConfig().then((c) => {
    cfg = c;
    bind();
    renderAll();
  });
})();
